import steamboiler.app.SteamBoilerApp;
import steamboiler.mode.BoilerMode;
import steamboiler.sensor.PumpReport;
import steamboiler.sensor.TransmissionData;

/** Local scenario validation (not part of the generated project). */
public class ScenarioCheck {

    static TransmissionData nominal(double level, double steam) {
        return TransmissionData.nominal(level, steam,
                PumpReport.nominal(false, false), PumpReport.nominal(false, false),
                PumpReport.nominal(false, false), PumpReport.nominal(false, false));
    }

    static TransmissionData withStop(double level, double steam) {
        TransmissionData n = nominal(level, steam);
        return new TransmissionData(true, false, false, true, level, true, steam,
                n.pump1(), n.pump2(), n.pump3(), n.pump4(),
                false, false, false, false, false);
    }

    static TransmissionData waiting(double level) {
        TransmissionData n = nominal(level, 0.0);
        return new TransmissionData(false, true, false, true, level, true, 0.0,
                n.pump1(), n.pump2(), n.pump3(), n.pump4(),
                false, false, false, false, false);
    }

    static TransmissionData ready(double level) {
        TransmissionData n = nominal(level, 0.0);
        return new TransmissionData(false, false, true, true, level, true, 0.0,
                n.pump1(), n.pump2(), n.pump3(), n.pump4(),
                false, false, false, false, false);
    }

    static void check(String name, boolean cond) {
        System.out.println((cond ? "PASS " : "FAIL ") + name);
    }

    public static void main(String[] args) {
        // S1: nominal start-up -> NORMAL
        SteamBoilerApp a = new SteamBoilerApp();
        a.cycle(waiting(500.0));
        a.cycle(ready(500.0));
        a.cycle(ready(500.0));
        check("S1 startup reaches NORMAL", a.controller().currentMode() == BoilerMode.NORMAL);

        // S2: STOP three times in a row -> EMERGENCY_STOP, terminal
        SteamBoilerApp b = new SteamBoilerApp();
        b.cycle(waiting(500.0));
        b.cycle(ready(500.0));
        b.cycle(ready(500.0));
        b.cycle(withStop(500.0, 0.0));
        b.cycle(withStop(500.0, 0.0));
        check("S2a two STOPs not yet emergency", b.controller().currentMode() == BoilerMode.NORMAL);
        b.cycle(withStop(500.0, 0.0));
        check("S2b three STOPs -> EMERGENCY_STOP", b.controller().currentMode() == BoilerMode.EMERGENCY_STOP);
        boolean accepted = b.cycle(nominal(500.0, 0.0));
        check("S2c terminal: further cycle refused", !accepted
                && b.controller().currentMode() == BoilerMode.EMERGENCY_STOP);

        // S3: steam nonzero in the WAITING-arrival cycle -> EMERGENCY_STOP (SB-Beh3)
        SteamBoilerApp c = new SteamBoilerApp();
        TransmissionData steamy = nominal(500.0, 5.0);
        c.cycle(new TransmissionData(false, true, false, true, 500.0, true, 5.0,
                steamy.pump1(), steamy.pump2(), steamy.pump3(), steamy.pump4(),
                false, false, false, false, false));
        check("S3 nonzero init steam -> EMERGENCY_STOP",
                c.controller().currentMode() == BoilerMode.EMERGENCY_STOP);

        // S4: transmission failure (missing level) in NORMAL -> EMERGENCY_STOP
        SteamBoilerApp d = new SteamBoilerApp();
        d.cycle(waiting(500.0));
        d.cycle(ready(500.0));
        d.cycle(ready(500.0));
        TransmissionData n4 = nominal(500.0, 0.0);
        d.cycle(new TransmissionData(false, false, false, false, 0.0, true, 0.0,
                n4.pump1(), n4.pump2(), n4.pump3(), n4.pump4(),
                false, false, false, false, false));
        check("S4 missing level message -> EMERGENCY_STOP",
                d.controller().currentMode() == BoilerMode.EMERGENCY_STOP);

        // S5: level device static-range failure in NORMAL -> RESCUE (SB-Beh11)
        SteamBoilerApp e = new SteamBoilerApp();
        e.cycle(waiting(500.0));
        e.cycle(ready(500.0));
        e.cycle(ready(500.0));
        e.cycle(nominal(2000.0, 0.0)); // above C -> level failure
        check("S5 level failure in NORMAL -> RESCUE",
                e.controller().currentMode() == BoilerMode.RESCUE);

        // S6: steam device failure in NORMAL -> DEGRADED (SB-Beh12); repair -> NORMAL (SB-Beh16)
        SteamBoilerApp f = new SteamBoilerApp();
        f.cycle(waiting(500.0));
        f.cycle(ready(500.0));
        f.cycle(ready(500.0));
        f.cycle(nominal(500.0, 60.0)); // above W -> steam failure
        check("S6a steam failure in NORMAL -> DEGRADED",
                f.controller().currentMode() == BoilerMode.DEGRADED);
        TransmissionData n6 = nominal(500.0, 0.0);
        f.cycle(new TransmissionData(false, false, false, true, 500.0, true, 0.0,
                n6.pump1(), n6.pump2(), n6.pump3(), n6.pump4(),
                false, true, false, false, false)); // STEAM_REPAIRED
        check("S6b steam repaired -> NORMAL",
                f.controller().currentMode() == BoilerMode.NORMAL);

        // S7: rescue with steam failure -> EMERGENCY_STOP (SB-Beh21)
        SteamBoilerApp g = new SteamBoilerApp();
        g.cycle(waiting(500.0));
        g.cycle(ready(500.0));
        g.cycle(ready(500.0));
        g.cycle(nominal(2000.0, 0.0)); // -> RESCUE
        g.cycle(nominal(2000.0, 60.0)); // steam failure while in rescue
        check("S7 steam failure in RESCUE -> EMERGENCY_STOP",
                g.controller().currentMode() == BoilerMode.EMERGENCY_STOP);

        // S8: init drain/fill behaviour (SB-Beh4/Beh5)
        SteamBoilerApp h = new SteamBoilerApp();
        h.cycle(waiting(700.0)); // above N2 -> valve
        check("S8a init level above N2 requests valve", h.actuator().valveRequested());
        SteamBoilerApp i = new SteamBoilerApp();
        i.cycle(waiting(300.0)); // below N1 -> open pump 1
        check("S8b init level below N1 opens a pump", i.actuator().openRequested(1));

        // S9: MODE broadcast every cycle (SB-Beh24)
        SteamBoilerApp j = new SteamBoilerApp();
        j.cycle(waiting(500.0));
        check("S9 MODE(m) broadcast reflects current mode",
                j.actuator().lastMode() == BoilerMode.INITIALIZATION);

        // S10: normal regulation pumps on below N1 (SB-Beh10)
        SteamBoilerApp k = new SteamBoilerApp();
        k.cycle(waiting(500.0));
        k.cycle(ready(500.0));
        k.cycle(ready(500.0));
        k.cycle(nominal(380.0, 0.0));
        check("S10 NORMAL below N1 opens pumps",
                k.actuator().openRequested(1) && k.actuator().openRequested(4)
                && k.controller().currentMode() == BoilerMode.NORMAL);
    }
}
