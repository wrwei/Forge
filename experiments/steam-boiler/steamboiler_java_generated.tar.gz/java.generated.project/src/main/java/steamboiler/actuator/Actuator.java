package steamboiler.actuator;

import steamboiler.annotation.RoboChartType;
import steamboiler.constants.BoilerConstants;
import steamboiler.event.OutputEvent;
import steamboiler.mode.BoilerMode;
import steamboiler.sensor.StatusRegister;

/**
 * Receives the program's outgoing messages (SB-DM8) and records the most
 * recent values for the transmission layer. Per-cycle order flags let the
 * boundary loop relay pump orders into the Sensor's expectation bookkeeping
 * (SB-FR1, SB-FR2).
 */
public final class Actuator {

    private BoilerMode lastMode;
    private boolean programReadySent;
    private boolean valveRequested;

    private final boolean[] openRequested = new boolean[BoilerConstants.PUMP_COUNT + 1];
    private final boolean[] closeRequested = new boolean[BoilerConstants.PUMP_COUNT + 1];

    @RoboChartType("nat")
    private int detectionsAnnounced;

    @RoboChartType("nat")
    private int repairsAcknowledged;

    public Actuator() {
        this.lastMode = BoilerMode.INITIALIZATION;
    }

    /** Clears the per-cycle flags; called by the boundary loop each cycle. */
    public void beginCycle() {
        this.programReadySent = false;
        this.valveRequested = false;
        for (int i = 1; i <= BoilerConstants.PUMP_COUNT; i++) {
            this.openRequested[i] = false;
            this.closeRequested[i] = false;
        }
    }

    public void receive(OutputEvent message) {
        if (message instanceof OutputEvent.ModeMessage) {
            OutputEvent.ModeMessage mm = (OutputEvent.ModeMessage) message;
            this.lastMode = mm.value();
        } else if (message instanceof OutputEvent.ProgramReady) {
            this.programReadySent = true;
        } else if (message instanceof OutputEvent.Valve) {
            this.valveRequested = true;
        } else if (message instanceof OutputEvent.OpenPump) {
            OutputEvent.OpenPump op = (OutputEvent.OpenPump) message;
            this.openRequested[op.pumpId()] = true;
        } else if (message instanceof OutputEvent.ClosePump) {
            OutputEvent.ClosePump cp = (OutputEvent.ClosePump) message;
            this.closeRequested[cp.pumpId()] = true;
        } else if (message instanceof OutputEvent.PumpFailureDetection) {
            this.detectionsAnnounced = this.detectionsAnnounced + 1;
        } else if (message instanceof OutputEvent.PumpControlFailureDetection) {
            this.detectionsAnnounced = this.detectionsAnnounced + 1;
        } else if (message instanceof OutputEvent.LevelFailureDetection) {
            this.detectionsAnnounced = this.detectionsAnnounced + 1;
        } else if (message instanceof OutputEvent.SteamFailureDetection) {
            this.detectionsAnnounced = this.detectionsAnnounced + 1;
        } else if (message instanceof OutputEvent.PumpRepairedAck) {
            this.repairsAcknowledged = this.repairsAcknowledged + 1;
        } else if (message instanceof OutputEvent.PumpControlRepairedAck) {
            this.repairsAcknowledged = this.repairsAcknowledged + 1;
        } else if (message instanceof OutputEvent.LevelRepairedAck) {
            this.repairsAcknowledged = this.repairsAcknowledged + 1;
        } else if (message instanceof OutputEvent.SteamRepairedAck) {
            this.repairsAcknowledged = this.repairsAcknowledged + 1;
        }
    }

    /**
     * Emits the persistent per-cycle protocol obligations (SB-FR6, SB-FR7):
     * every unacknowledged failure detection is announced again, and every
     * due repair acknowledgement is sent and cleared.
     */
    public void announcePending(StatusRegister register) {
        for (int i = 1; i <= BoilerConstants.PUMP_COUNT; i++) {
            if (register.pumpDetectionPending(i)) {
                receive(new OutputEvent.PumpFailureDetection(i));
            }
            if (register.controlDetectionPending(i)) {
                receive(new OutputEvent.PumpControlFailureDetection(i));
            }
            if (register.pumpRepairAckDue(i)) {
                receive(new OutputEvent.PumpRepairedAck(i));
                register.clearPumpRepairAck(i);
            }
            if (register.controlRepairAckDue(i)) {
                receive(new OutputEvent.PumpControlRepairedAck(i));
                register.clearControlRepairAck(i);
            }
        }
        if (register.levelDetectionPending()) {
            receive(new OutputEvent.LevelFailureDetection());
        }
        if (register.steamDetectionPending()) {
            receive(new OutputEvent.SteamFailureDetection());
        }
        if (register.levelRepairAckDue()) {
            receive(new OutputEvent.LevelRepairedAck());
            register.clearLevelRepairAck();
        }
        if (register.steamRepairAckDue()) {
            receive(new OutputEvent.SteamRepairedAck());
            register.clearSteamRepairAck();
        }
    }

    public BoilerMode lastMode() {
        return lastMode;
    }

    public boolean programReadySent() {
        return programReadySent;
    }

    public boolean valveRequested() {
        return valveRequested;
    }

    public boolean openRequested(@RoboChartType("nat") int pumpId) {
        return openRequested[pumpId];
    }

    public boolean closeRequested(@RoboChartType("nat") int pumpId) {
        return closeRequested[pumpId];
    }

    @RoboChartType("nat")
    public int detectionsAnnounced() {
        return detectionsAnnounced;
    }

    @RoboChartType("nat")
    public int repairsAcknowledged() {
        return repairsAcknowledged;
    }
}
