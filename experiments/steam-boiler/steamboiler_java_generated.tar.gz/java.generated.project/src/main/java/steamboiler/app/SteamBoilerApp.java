package steamboiler.app;

import steamboiler.actuator.Actuator;
import steamboiler.controller.BoilerController;
import steamboiler.event.InputEvent;
import steamboiler.mode.BoilerMode;
import steamboiler.operation.CalcLevelEstimate;
import steamboiler.operation.CalcThroughput;
import steamboiler.sensor.Sensor;
import steamboiler.sensor.StatusRegister;
import steamboiler.sensor.TransmissionData;

/**
 * Top-level system wiring (SB-V1): holds the singleton Sensor, StatusRegister,
 * operations, Actuator and BoilerController, and exposes a single
 * {@link #cycle(TransmissionData)} that performs one five-second control
 * cycle (SB-V3): receive the batch, analyse, transmit. After the controller
 * enters emergency stop the program's control task has ended (SB-Beh22) and
 * further cycles are refused.
 */
public final class SteamBoilerApp {

    private final StatusRegister register = new StatusRegister();
    private final Sensor sensor = new Sensor(register);
    private final Actuator actuator = new Actuator();
    private final CalcThroughput calcThroughput = new CalcThroughput(sensor);
    private final CalcLevelEstimate calcLevelEstimate = new CalcLevelEstimate(sensor);
    private final BoilerController controller =
            new BoilerController(sensor, actuator, calcThroughput, calcLevelEstimate);

    public Sensor sensor() {
        return sensor;
    }

    public Actuator actuator() {
        return actuator;
    }

    public BoilerController controller() {
        return controller;
    }

    /** The program has halted in the terminal emergency-stop mode (SB-Beh22). */
    public boolean halted() {
        return controller.currentMode() == BoilerMode.EMERGENCY_STOP;
    }

    /**
     * One control cycle (SB-V3): ingest the incoming transmission batch,
     * step the controller, then relay this cycle's pump orders into the
     * Sensor's expectation bookkeeping (SB-FR1, SB-FR2) and emit the
     * persistent failure/repair protocol messages (SB-FR6, SB-FR7).
     * Returns false when the program has already halted.
     */
    public boolean cycle(TransmissionData batch) {
        if (halted()) {
            return false;
        }
        actuator.beginCycle();
        sensor.ingest(batch);
        controller.step(new InputEvent.Transmission());
        for (int i = 1; i <= steamboiler.constants.BoilerConstants.PUMP_COUNT; i++) {
            if (actuator.openRequested(i)) {
                sensor.notePumpOrder(i, true);
            }
            if (actuator.closeRequested(i)) {
                sensor.notePumpOrder(i, false);
            }
        }
        actuator.announcePending(register);
        return !halted();
    }

    /** Demo entry point: runs a short nominal start-up scenario. */
    public static void main(String[] args) {
        SteamBoilerApp app = new SteamBoilerApp();
        TransmissionData waiting = new TransmissionData(
                false, true, false,
                true, 500.0, true, 0.0,
                steamboiler.sensor.PumpReport.nominal(false, false),
                steamboiler.sensor.PumpReport.nominal(false, false),
                steamboiler.sensor.PumpReport.nominal(false, false),
                steamboiler.sensor.PumpReport.nominal(false, false),
                false, false, false, false, false);
        app.cycle(waiting);
        System.out.println("mode after waiting cycle: " + app.controller().currentMode());
        TransmissionData ready = new TransmissionData(
                false, false, true,
                true, 500.0, true, 0.0,
                steamboiler.sensor.PumpReport.nominal(false, false),
                steamboiler.sensor.PumpReport.nominal(false, false),
                steamboiler.sensor.PumpReport.nominal(false, false),
                steamboiler.sensor.PumpReport.nominal(false, false),
                false, false, false, false, false);
        app.cycle(ready);
        app.cycle(ready);
        System.out.println("mode after ready cycles: " + app.controller().currentMode());
    }
}
