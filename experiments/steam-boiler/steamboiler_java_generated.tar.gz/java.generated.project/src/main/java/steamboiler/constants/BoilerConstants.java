package steamboiler.constants;

import steamboiler.annotation.RoboChartType;

/**
 * Physical characteristics of the steam boiler plant (SB-DM1, SB-DM2,
 * SB-DM3) and derived protocol constants (SB-V10, SB-V1). Abrial's
 * specification names the constants but fixes no numeric values; the
 * values below are a consistent instantiation satisfying
 * M1 &lt; N1 &lt; N2 &lt; M2 &lt; C.
 */
public final class BoilerConstants {

    /** Total boiler capacity C (litre). SB-DM1. */
    @RoboChartType("real")
    public static final double C = 1000.0;

    /** Minimal limit M1 (litre): danger below after five seconds. SB-DM1. */
    @RoboChartType("real")
    public static final double M1 = 150.0;

    /** Maximal limit M2 (litre): danger above after five seconds. SB-DM1. */
    @RoboChartType("real")
    public static final double M2 = 850.0;

    /** Minimal normal level N1 (litre). SB-DM1. */
    @RoboChartType("real")
    public static final double N1 = 400.0;

    /** Maximal normal level N2 (litre). SB-DM1. */
    @RoboChartType("real")
    public static final double N2 = 600.0;

    /** Maximal steam rate W (litre/sec). SB-DM2. */
    @RoboChartType("real")
    public static final double W = 25.0;

    /** Maximal steam-rate increase gradient U1 (litre/sec/sec). SB-DM2. */
    @RoboChartType("real")
    public static final double U1 = 5.0;

    /** Maximal steam-rate decrease gradient U2 (litre/sec/sec). SB-DM2. */
    @RoboChartType("real")
    public static final double U2 = 5.0;

    /** Nominal capacity P of each pump (litre/sec). SB-DM3. */
    @RoboChartType("real")
    public static final double P = 15.0;

    /** Cycle period (seconds). SB-V3. */
    @RoboChartType("real")
    public static final double CYCLE_SECONDS = 5.0;

    /** Number of pumps (and pump controllers). SB-V1, SB-DM3. */
    @RoboChartType("nat")
    public static final int PUMP_COUNT = 4;

    /** Successive STOP receptions forcing emergency stop. SB-Beh23, SB-V10. */
    @RoboChartType("nat")
    public static final int STOP_REPEAT_LIMIT = 3;

    private BoilerConstants() {
        // utility class - no instances
    }
}
