package steamboiler.controller;

import steamboiler.actuator.Actuator;
import steamboiler.constants.BoilerConstants;
import steamboiler.event.InputEvent;
import steamboiler.event.OutputEvent;
import steamboiler.mode.BoilerMode;
import steamboiler.operation.CalcLevelEstimate;
import steamboiler.operation.CalcThroughput;
import steamboiler.sensor.Sensor;

/**
 * The steam-boiler control program (SB-V1): a single-method, mode-nested
 * if-else state machine over the five {@link BoilerMode}s (SB-V2). One call
 * to {@link #step(InputEvent)} handles one five-second cycle (SB-V3): the
 * incoming batch has already been ingested by the Sensor layer, the derived
 * quantities are refreshed through the operations, and exactly one outgoing
 * transition of the current mode is selected.
 *
 * <p>Priority discipline (SB-FR8): within every mode block the inner chain
 * is ordered emergency-stop conditions first (transmission failure, STOP
 * demand, level risk, and in rescue the vital-unit failures), then rescue,
 * then degraded, then regulation. Every branch conjoins the explicit
 * negation of each higher-priority triggerless guard, per the admitted
 * convention (see reference-runs/lre LreController).
 *
 * <p>Emergency stop is terminal (SB-Beh22): its mode block is empty — the
 * program's control task has ended and no transition leaves the mode. The
 * final MODE(emergency stop) message is emitted inline on each transition
 * into the mode; thereafter the program stops (the boundary loop halts).
 */
public final class BoilerController {

    private BoilerMode currentMode = BoilerMode.INITIALIZATION;

    private final Sensor sensor;
    private final Actuator actuator;
    private final CalcThroughput calcThroughput;
    private final CalcLevelEstimate calcLevelEstimate;

    // ---- Guard predicate fields, refreshed each step (SB-FR8 priority
    // discipline). Stored as instance FIELDS rather than method-local
    // booleans on purpose: the M2T-Dafny template inlines local boolean
    // predicates into their underlying expression, which re-introduces
    // sensor function calls (reads this) into the emitted postconditions;
    // those cannot be proven stable across mode := X in Dafny's frame
    // analysis. Promoting the predicates to fields makes the postconditions
    // reference the field names directly (see the LRE reference controller's
    // iteration-3 diagnosis of the same defect). ----

    private boolean transmissionFailed;
    private boolean stopThresholdReached;
    private boolean initSteamDefect;
    private boolean levelDeviceFailed;
    private boolean steamDeviceFailed;
    private boolean controlUnitFailed;
    private boolean nonLevelUnitFailed;
    private boolean everyUnitSound;
    private boolean levelRiskM1M2;
    private boolean levelBelowN1;
    private boolean levelAboveN2;
    private boolean plantWaiting;
    private boolean unitsReady;
    private boolean initDrainNeeded;
    private boolean initFillNeeded;
    private boolean initReadyPhase;
    private boolean initExitAllSound;
    private boolean initExitDegraded;
    private boolean rescueRepairToDegraded;

    public BoilerController(
            Sensor sensor,
            Actuator actuator,
            CalcThroughput calcThroughput,
            CalcLevelEstimate calcLevelEstimate) {
        this.sensor = sensor;
        this.actuator = actuator;
        this.calcThroughput = calcThroughput;
        this.calcLevelEstimate = calcLevelEstimate;
    }

    public BoilerMode currentMode() {
        return currentMode;
    }

    public void step(InputEvent event) {
        // --- Refresh derived quantities (SB-V7, SB-V8) ---
        calcThroughput.compute();
        calcLevelEstimate.compute();

        // --- Named guard predicate fields, refreshed BEFORE the if-else chain
        //     (fields, not locals -- see field-block comment) ---
        this.transmissionFailed = sensor.transmissionBroken();
        this.stopThresholdReached = sensor.stopCount() >= BoilerConstants.STOP_REPEAT_LIMIT;
        this.initSteamDefect = sensor.initialSteamDefect();
        this.levelDeviceFailed = sensor.levelDeviceBroken();
        this.steamDeviceFailed = sensor.steamDeviceBroken();
        this.controlUnitFailed = sensor.anyControlUnitBroken();
        this.nonLevelUnitFailed = sensor.anyNonLevelUnitBroken();
        this.everyUnitSound = sensor.allUnitsSound();
        this.levelRiskM1M2 = calcLevelEstimate.riskBelowM1() || calcLevelEstimate.riskAboveM2();
        this.levelBelowN1 = calcLevelEstimate.levelLow() < BoilerConstants.N1;
        this.levelAboveN2 = calcLevelEstimate.levelHigh() > BoilerConstants.N2;
        this.plantWaiting = sensor.plantAnnounced();
        this.unitsReady = sensor.unitsReadySeen();
        this.initDrainNeeded = this.plantWaiting && this.levelAboveN2 && !this.unitsReady;
        this.initFillNeeded = this.plantWaiting && this.levelBelowN1 && !this.unitsReady;
        this.initReadyPhase = this.plantWaiting && !this.levelBelowN1 && !this.levelAboveN2 && !this.unitsReady;
        this.initExitAllSound = this.plantWaiting && this.unitsReady && this.everyUnitSound;
        this.initExitDegraded = this.plantWaiting && this.unitsReady && !this.everyUnitSound;
        this.rescueRepairToDegraded = !this.levelDeviceFailed && this.nonLevelUnitFailed;

        // --- Pure mode-nested if-else: one outer block per mode (SB-V2) ---
        if (currentMode == BoilerMode.INITIALIZATION) {
            // SB-Beh24 - MODE(m) broadcast for this cycle.
            actuator.receive(new OutputEvent.ModeMessage(currentMode));
            // SB-Beh9 - transmission failure during init -> emergency stop
            if (transmissionFailed) {
                currentMode = BoilerMode.EMERGENCY_STOP;
                actuator.receive(new OutputEvent.ModeMessage(BoilerMode.EMERGENCY_STOP));
            }
            // SB-Beh23 - STOP three times in a row -> emergency stop
            else if (stopThresholdReached && !transmissionFailed) {
                currentMode = BoilerMode.EMERGENCY_STOP;
                actuator.receive(new OutputEvent.ModeMessage(BoilerMode.EMERGENCY_STOP));
            }
            // SB-Beh3 - initial steam rate not zero -> emergency stop
            else if (initSteamDefect && !transmissionFailed && !stopThresholdReached) {
                currentMode = BoilerMode.EMERGENCY_STOP;
                actuator.receive(new OutputEvent.ModeMessage(BoilerMode.EMERGENCY_STOP));
            }
            // SB-Beh6 - level device failure during init -> emergency stop
            else if (levelDeviceFailed && !transmissionFailed && !stopThresholdReached
                    && !initSteamDefect) {
                currentMode = BoilerMode.EMERGENCY_STOP;
                actuator.receive(new OutputEvent.ModeMessage(BoilerMode.EMERGENCY_STOP));
            }
            // SB-Beh4 - drain excess start-up water through the valve
            else if (initDrainNeeded && !transmissionFailed && !stopThresholdReached
                    && !initSteamDefect && !levelDeviceFailed) {
                currentMode = BoilerMode.INITIALIZATION;
                actuator.receive(new OutputEvent.Valve());
            }
            // SB-Beh5 - fill low start-up water with a pump
            else if (initFillNeeded && !transmissionFailed && !stopThresholdReached
                    && !initSteamDefect && !levelDeviceFailed && !initDrainNeeded) {
                currentMode = BoilerMode.INITIALIZATION;
                actuator.receive(new OutputEvent.OpenPump(1));
            }
            // SB-Beh7 - level settled: announce PROGRAM_READY until answered
            else if (initReadyPhase && !transmissionFailed && !stopThresholdReached
                    && !initSteamDefect && !levelDeviceFailed && !initDrainNeeded
                    && !initFillNeeded) {
                currentMode = BoilerMode.INITIALIZATION;
                actuator.receive(new OutputEvent.ProgramReady());
            }
            // SB-Beh8 - PHYSICAL_UNITS_READY, all units sound -> normal
            else if (initExitAllSound && !transmissionFailed && !stopThresholdReached
                    && !initSteamDefect && !levelDeviceFailed && !initDrainNeeded
                    && !initFillNeeded && !initReadyPhase) {
                currentMode = BoilerMode.NORMAL;
            }
            // SB-Beh8 - PHYSICAL_UNITS_READY, some unit defective -> degraded
            else if (initExitDegraded && !transmissionFailed && !stopThresholdReached
                    && !initSteamDefect && !levelDeviceFailed && !initDrainNeeded
                    && !initFillNeeded && !initReadyPhase && !initExitAllSound) {
                currentMode = BoilerMode.DEGRADED;
            }
            // SB-Beh2 - waiting for STEAM_BOILER_WAITING
            else {
                currentMode = BoilerMode.INITIALIZATION;
            }

        } else if (currentMode == BoilerMode.NORMAL) {
            // SB-Beh24 - MODE(m) broadcast for this cycle.
            actuator.receive(new OutputEvent.ModeMessage(currentMode));
            // SB-Beh14 - transmission failure -> emergency stop
            if (transmissionFailed) {
                currentMode = BoilerMode.EMERGENCY_STOP;
                actuator.receive(new OutputEvent.ModeMessage(BoilerMode.EMERGENCY_STOP));
            }
            // SB-Beh23 - STOP three times in a row -> emergency stop
            else if (stopThresholdReached && !transmissionFailed) {
                currentMode = BoilerMode.EMERGENCY_STOP;
                actuator.receive(new OutputEvent.ModeMessage(BoilerMode.EMERGENCY_STOP));
            }
            // SB-Beh13 - level risks M1/M2 (worst case) -> emergency stop
            else if (levelRiskM1M2 && !transmissionFailed && !stopThresholdReached) {
                currentMode = BoilerMode.EMERGENCY_STOP;
                actuator.receive(new OutputEvent.ModeMessage(BoilerMode.EMERGENCY_STOP));
            }
            // SB-Beh11 - level device failure -> rescue
            else if (levelDeviceFailed && !transmissionFailed && !stopThresholdReached
                    && !levelRiskM1M2) {
                currentMode = BoilerMode.RESCUE;
            }
            // SB-Beh12 - any other unit failure -> degraded
            else if (nonLevelUnitFailed && !transmissionFailed && !stopThresholdReached
                    && !levelRiskM1M2 && !levelDeviceFailed) {
                currentMode = BoilerMode.DEGRADED;
            }
            // SB-Beh10 - level below N1: switch the pumps on
            else if (levelBelowN1 && !transmissionFailed && !stopThresholdReached
                    && !levelRiskM1M2 && !levelDeviceFailed && !nonLevelUnitFailed) {
                currentMode = BoilerMode.NORMAL;
                actuator.receive(new OutputEvent.OpenPump(1));
                actuator.receive(new OutputEvent.OpenPump(2));
                actuator.receive(new OutputEvent.OpenPump(3));
                actuator.receive(new OutputEvent.OpenPump(4));
            }
            // SB-Beh10 - level above N2: switch the pumps off
            else if (levelAboveN2 && !transmissionFailed && !stopThresholdReached
                    && !levelRiskM1M2 && !levelDeviceFailed && !nonLevelUnitFailed
                    && !levelBelowN1) {
                currentMode = BoilerMode.NORMAL;
                actuator.receive(new OutputEvent.ClosePump(1));
                actuator.receive(new OutputEvent.ClosePump(2));
                actuator.receive(new OutputEvent.ClosePump(3));
                actuator.receive(new OutputEvent.ClosePump(4));
            }
            // SB-Beh10 - level satisfactory: remain in normal mode
            else {
                currentMode = BoilerMode.NORMAL;
            }

        } else if (currentMode == BoilerMode.DEGRADED) {
            // SB-Beh24 - MODE(m) broadcast for this cycle.
            actuator.receive(new OutputEvent.ModeMessage(currentMode));
            // SB-Beh18 - transmission failure -> emergency stop
            if (transmissionFailed) {
                currentMode = BoilerMode.EMERGENCY_STOP;
                actuator.receive(new OutputEvent.ModeMessage(BoilerMode.EMERGENCY_STOP));
            }
            // SB-Beh23 - STOP three times in a row -> emergency stop
            else if (stopThresholdReached && !transmissionFailed) {
                currentMode = BoilerMode.EMERGENCY_STOP;
                actuator.receive(new OutputEvent.ModeMessage(BoilerMode.EMERGENCY_STOP));
            }
            // SB-Beh18 - level risks M1/M2 -> emergency stop
            else if (levelRiskM1M2 && !transmissionFailed && !stopThresholdReached) {
                currentMode = BoilerMode.EMERGENCY_STOP;
                actuator.receive(new OutputEvent.ModeMessage(BoilerMode.EMERGENCY_STOP));
            }
            // SB-Beh17 - level device failure -> rescue
            else if (levelDeviceFailed && !transmissionFailed && !stopThresholdReached
                    && !levelRiskM1M2) {
                currentMode = BoilerMode.RESCUE;
            }
            // SB-Beh16 - every failed unit repaired -> back to normal
            else if (everyUnitSound && !transmissionFailed && !stopThresholdReached
                    && !levelRiskM1M2 && !levelDeviceFailed) {
                currentMode = BoilerMode.NORMAL;
            }
            // SB-Beh15 - regulation as in normal mode: level below N1
            else if (levelBelowN1 && !transmissionFailed && !stopThresholdReached
                    && !levelRiskM1M2 && !levelDeviceFailed && !everyUnitSound) {
                currentMode = BoilerMode.DEGRADED;
                actuator.receive(new OutputEvent.OpenPump(1));
                actuator.receive(new OutputEvent.OpenPump(2));
                actuator.receive(new OutputEvent.OpenPump(3));
                actuator.receive(new OutputEvent.OpenPump(4));
            }
            // SB-Beh15 - regulation as in normal mode: level above N2
            else if (levelAboveN2 && !transmissionFailed && !stopThresholdReached
                    && !levelRiskM1M2 && !levelDeviceFailed && !everyUnitSound
                    && !levelBelowN1) {
                currentMode = BoilerMode.DEGRADED;
                actuator.receive(new OutputEvent.ClosePump(1));
                actuator.receive(new OutputEvent.ClosePump(2));
                actuator.receive(new OutputEvent.ClosePump(3));
                actuator.receive(new OutputEvent.ClosePump(4));
            }
            // SB-Beh15 - level satisfactory: remain in degraded mode
            else {
                currentMode = BoilerMode.DEGRADED;
            }

        } else if (currentMode == BoilerMode.RESCUE) {
            // SB-Beh24 - MODE(m) broadcast for this cycle.
            actuator.receive(new OutputEvent.ModeMessage(currentMode));
            // SB-Beh21 - transmission failure -> emergency stop
            if (transmissionFailed) {
                currentMode = BoilerMode.EMERGENCY_STOP;
                actuator.receive(new OutputEvent.ModeMessage(BoilerMode.EMERGENCY_STOP));
            }
            // SB-Beh23 - STOP three times in a row -> emergency stop
            else if (stopThresholdReached && !transmissionFailed) {
                currentMode = BoilerMode.EMERGENCY_STOP;
                actuator.receive(new OutputEvent.ModeMessage(BoilerMode.EMERGENCY_STOP));
            }
            // SB-Beh21 - steam device failure: estimate untrustworthy -> emergency stop
            else if (steamDeviceFailed && !transmissionFailed && !stopThresholdReached) {
                currentMode = BoilerMode.EMERGENCY_STOP;
                actuator.receive(new OutputEvent.ModeMessage(BoilerMode.EMERGENCY_STOP));
            }
            // SB-Beh21 - pump-controller failure: inflow unknown -> emergency stop
            else if (controlUnitFailed && !transmissionFailed && !stopThresholdReached
                    && !steamDeviceFailed) {
                currentMode = BoilerMode.EMERGENCY_STOP;
                actuator.receive(new OutputEvent.ModeMessage(BoilerMode.EMERGENCY_STOP));
            }
            // SB-Beh21 - estimated level risks M1/M2 -> emergency stop
            else if (levelRiskM1M2 && !transmissionFailed && !stopThresholdReached
                    && !steamDeviceFailed && !controlUnitFailed) {
                currentMode = BoilerMode.EMERGENCY_STOP;
                actuator.receive(new OutputEvent.ModeMessage(BoilerMode.EMERGENCY_STOP));
            }
            // SB-Beh20 - level device repaired, all units sound -> normal
            else if (everyUnitSound && !transmissionFailed && !stopThresholdReached
                    && !steamDeviceFailed && !controlUnitFailed && !levelRiskM1M2) {
                currentMode = BoilerMode.NORMAL;
            }
            // SB-Beh20 - level device repaired, another unit defective -> degraded
            else if (rescueRepairToDegraded && !transmissionFailed && !stopThresholdReached
                    && !steamDeviceFailed && !controlUnitFailed && !levelRiskM1M2
                    && !everyUnitSound) {
                currentMode = BoilerMode.DEGRADED;
            }
            // SB-Beh19 - regulate on the estimate: lower bound below N1
            else if (levelBelowN1 && !transmissionFailed && !stopThresholdReached
                    && !steamDeviceFailed && !controlUnitFailed && !levelRiskM1M2
                    && !everyUnitSound && !rescueRepairToDegraded) {
                currentMode = BoilerMode.RESCUE;
                actuator.receive(new OutputEvent.OpenPump(1));
                actuator.receive(new OutputEvent.OpenPump(2));
                actuator.receive(new OutputEvent.OpenPump(3));
                actuator.receive(new OutputEvent.OpenPump(4));
            }
            // SB-Beh19 - regulate on the estimate: upper bound above N2
            else if (levelAboveN2 && !transmissionFailed && !stopThresholdReached
                    && !steamDeviceFailed && !controlUnitFailed && !levelRiskM1M2
                    && !everyUnitSound && !rescueRepairToDegraded && !levelBelowN1) {
                currentMode = BoilerMode.RESCUE;
                actuator.receive(new OutputEvent.ClosePump(1));
                actuator.receive(new OutputEvent.ClosePump(2));
                actuator.receive(new OutputEvent.ClosePump(3));
                actuator.receive(new OutputEvent.ClosePump(4));
            }
            // SB-Beh19 - estimate satisfactory: remain in rescue mode
            else {
                currentMode = BoilerMode.RESCUE;
            }

        } else if (currentMode == BoilerMode.EMERGENCY_STOP) {
            // SB-Beh22 - terminal mode: the control task has ended; the
            // physical environment takes responsibility. No transition
            // leaves this mode and no message is emitted.
        }
    }
}
