package steamboiler.event;

/**
 * Input events delivered to the controller. The steam-boiler protocol is
 * cycle-batched (SB-V3): within one transmission all incoming messages
 * arrive simultaneously, so the single controller-visible event is one
 * {@link Transmission} tick per cycle. The batch content itself is parsed
 * into the Sensor layer before {@code step} runs (encoding choice for the
 * batched-input construct; see encoding_choices.md).
 */
public sealed interface InputEvent {
    /** One received per five-second cycle after the batch is ingested. */
    record Transmission() implements InputEvent {}
}
