package steamboiler.event;

import steamboiler.annotation.RoboChartType;
import steamboiler.mode.BoilerMode;

/**
 * Output messages from the program to the physical units (SB-DM8).
 */
public sealed interface OutputEvent {

    /** MODE(m) - current operating mode, sent on every cycle. SB-Beh24. */
    record ModeMessage(BoilerMode value) implements OutputEvent {}

    /** PROGRAM_READY - repeated until PHYSICAL_UNITS_READY. SB-Beh7. */
    record ProgramReady() implements OutputEvent {}

    /** VALVE - request opening, then closure, of the evacuation valve. SB-Beh4, SB-DM7. */
    record Valve() implements OutputEvent {}

    /** OPEN_PUMP(n) - activate pump n. SB-Beh5, SB-Beh10. */
    record OpenPump(@RoboChartType("nat") int pumpId) implements OutputEvent {}

    /** CLOSE_PUMP(n) - stop pump n. SB-Beh10. */
    record ClosePump(@RoboChartType("nat") int pumpId) implements OutputEvent {}

    /** PUMP_FAILURE_DETECTION(n) - repeated until acknowledged. SB-FR1, SB-FR6. */
    record PumpFailureDetection(@RoboChartType("nat") int pumpId) implements OutputEvent {}

    /** PUMP_CONTROL_FAILURE_DETECTION(n) - repeated until acknowledged. SB-FR2, SB-FR6. */
    record PumpControlFailureDetection(@RoboChartType("nat") int pumpId) implements OutputEvent {}

    /** LEVEL_FAILURE_DETECTION - repeated until acknowledged. SB-FR3, SB-FR6. */
    record LevelFailureDetection() implements OutputEvent {}

    /** STEAM_FAILURE_DETECTION - repeated until acknowledged. SB-FR4, SB-FR6. */
    record SteamFailureDetection() implements OutputEvent {}

    /** PUMP_REPAIRED_ACKNOWLEDGEMENT(n). SB-FR7. */
    record PumpRepairedAck(@RoboChartType("nat") int pumpId) implements OutputEvent {}

    /** PUMP_CONTROL_REPAIRED_ACKNOWLEDGEMENT(n). SB-FR7. */
    record PumpControlRepairedAck(@RoboChartType("nat") int pumpId) implements OutputEvent {}

    /** LEVEL_REPAIRED_ACKNOWLEDGEMENT. SB-FR7. */
    record LevelRepairedAck() implements OutputEvent {}

    /** STEAM_REPAIRED_ACKNOWLEDGEMENT. SB-FR7. */
    record SteamRepairedAck() implements OutputEvent {}
}
