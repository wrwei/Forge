package steamboiler.mode;

/**
 * The five operating modes of the steam-boiler control program (SB-V2,
 * SB-DM10). The program starts in {@link #INITIALIZATION} (SB-Beh1);
 * {@link #EMERGENCY_STOP} is terminal (SB-Beh22).
 */
public enum BoilerMode {
    INITIALIZATION,
    NORMAL,
    DEGRADED,
    RESCUE,
    EMERGENCY_STOP
}
