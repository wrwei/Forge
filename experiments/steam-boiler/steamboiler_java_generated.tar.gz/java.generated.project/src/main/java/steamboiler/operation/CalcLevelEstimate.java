package steamboiler.operation;

import steamboiler.annotation.RoboChartType;
import steamboiler.constants.BoilerConstants;
import steamboiler.sensor.Sensor;

/**
 * Maintains the level estimate interval and the M1/M2 risk predicates
 * (SB-V8, SB-Beh13, SB-Beh19). While the level device is sound the interval
 * collapses onto the accepted reading; while it is out of order the interval
 * is advanced each cycle from its previous value using the maximal steam
 * dynamics (W, U1, U2) and the water known to be supplied by the pumps,
 * one supplied litre counting as one litre of content (SB-Beh19), with the
 * pump start latency respected (SB-Beh25).
 *
 * <p>This operation carries state across cycles: {@code projLow} and
 * {@code projHigh} computed in cycle t are the carried-over candidates read
 * in cycle t+1.
 */
public final class CalcLevelEstimate {

    private final Sensor sensor;

    /** Lower bound on the current water level (litre). */
    @RoboChartType("real")
    private double levelLow;

    /** Upper bound on the current water level (litre). */
    @RoboChartType("real")
    private double levelHigh;

    /** Worst-case lower bound projected one cycle ahead (litre). */
    @RoboChartType("real")
    private double projLow;

    /** Worst-case upper bound projected one cycle ahead (litre). */
    @RoboChartType("real")
    private double projHigh;

    /** The level risks reaching M1 within one worst-case cycle (SB-Beh13). */
    private boolean riskBelowM1;

    /** The level risks reaching M2 within one worst-case cycle (SB-Beh13). */
    private boolean riskAboveM2;

    public CalcLevelEstimate(Sensor sensor) {
        this.sensor = sensor;
        this.levelLow = 0.0;
        this.levelHigh = BoilerConstants.C;
        this.projLow = 0.0;
        this.projHigh = BoilerConstants.C;
        this.riskBelowM1 = false;
        this.riskAboveM2 = false;
    }

    public void compute() {
        this.levelLow = sensor.baseLevelLow(this.projLow);
        this.levelHigh = sensor.baseLevelHigh(this.projHigh);
        this.projLow = this.levelLow - sensor.maxSteamOutPerCycle() + sensor.minPumpInPerCycle();
        this.projHigh = this.levelHigh - sensor.minSteamOutPerCycle() + sensor.maxPumpInPerCycle();
        this.riskBelowM1 = this.projLow <= BoilerConstants.M1;
        this.riskAboveM2 = this.projHigh >= BoilerConstants.M2;
    }

    @RoboChartType("real")
    public double levelLow() {
        return levelLow;
    }

    @RoboChartType("real")
    public double levelHigh() {
        return levelHigh;
    }

    public boolean riskBelowM1() {
        return riskBelowM1;
    }

    public boolean riskAboveM2() {
        return riskAboveM2;
    }
}
