package steamboiler.operation;

import steamboiler.annotation.RoboChartType;
import steamboiler.sensor.Sensor;

/**
 * Maintains the derived quantity p — the current combined throughput of the
 * pumps (litre/sec, SB-V7). No device reports p directly; it is derived
 * from the reported pump states, the pump-controller observations, and the
 * nominal per-pump capacity P (statically unrolled over the four pumps,
 * SB-DM3).
 */
public final class CalcThroughput {

    private final Sensor sensor;

    @RoboChartType("real")
    private double p;

    public CalcThroughput(Sensor sensor) {
        this.sensor = sensor;
        this.p = 0.0;
    }

    public void compute() {
        this.p = sensor.pumpInflow(1) + sensor.pumpInflow(2)
                + sensor.pumpInflow(3) + sensor.pumpInflow(4);
    }

    @RoboChartType("real")
    public double p() {
        return p;
    }
}
