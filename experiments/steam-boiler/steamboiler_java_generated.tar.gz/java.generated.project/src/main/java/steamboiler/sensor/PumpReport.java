package steamboiler.sensor;

/**
 * The per-pump slice of one incoming transmission: PUMP_STATE(n, b) and
 * PUMP_CONTROL_STATE(n, b) (both required every transmission, SB-DM9),
 * plus the optional repair notifications and failure acknowledgements
 * for pump n and its controller (SB-FR6, SB-FR7).
 */
public record PumpReport(
        boolean statePresent,
        boolean running,
        boolean flowPresent,
        boolean flows,
        boolean pumpRepaired,
        boolean controlRepaired,
        boolean pumpFailureAck,
        boolean controlFailureAck) {

    /** A nominal in-cycle report: state present, given on/flow values, no repairs/acks. */
    public static PumpReport nominal(boolean running, boolean flows) {
        return new PumpReport(true, running, true, flows, false, false, false, false);
    }
}
