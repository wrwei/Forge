package steamboiler.sensor;

import steamboiler.annotation.RoboChartType;
import steamboiler.constants.BoilerConstants;

/**
 * Ingests one {@link TransmissionData} batch per five-second cycle (SB-V3)
 * and exposes the controller-facing view of the plant: current readings,
 * protocol-phase latches, the STOP counter (SB-V10), transmission-failure
 * verdicts (SB-FR5), and the unit failure detections (SB-FR1..SB-FR4)
 * recorded in the {@link StatusRegister} (SB-V9).
 *
 * <p>All controller-guard-facing methods return plain values with safe
 * defaults; no sentinel values reach the controller. Worst-case per-cycle
 * water-balance bounds (used by the level estimation operation, SB-V8,
 * SB-Beh13, SB-Beh25) are computed here so operation compute() bodies stay
 * assignment-only.
 */
public final class Sensor {

    private final StatusRegister register;

    // ---- protocol-phase latches (SB-Beh2, SB-Beh7) ----
    private boolean plantAnnounced;
    private boolean unitsReadySeen;
    private boolean initialSteamChecked;
    private boolean initialSteamDefect;

    // ---- current readings (SB-V5, SB-V6) ----
    @RoboChartType("real")
    private double waterLevel;

    @RoboChartType("real")
    private double steamRate;

    private boolean hasAcceptedLevel;

    @RoboChartType("real")
    private double lastAcceptedLevel;

    private boolean hasAcceptedSteam;

    @RoboChartType("real")
    private double lastAcceptedSteam;

    // ---- per-pump reported states and expectations (1-based, index 0 unused) ----
    private final boolean[] pumpOn = new boolean[BoilerConstants.PUMP_COUNT + 1];
    private final boolean[] pumpFlow = new boolean[BoilerConstants.PUMP_COUNT + 1];
    private final boolean[] expectedOn = new boolean[BoilerConstants.PUMP_COUNT + 1];
    private final boolean[] prevFlow = new boolean[BoilerConstants.PUMP_COUNT + 1];

    /**
     * Cycles since a state-changing order to pump n: 0 = no order pending;
     * 1 = the next incoming transmission is the first after the order
     * (pump-state check, SB-FR1); 2 = second transmission after the order
     * (flow check, SB-FR2 — one extra cycle for the five-second pump start
     * latency, SB-Beh25, SB-DM3).
     */
    @RoboChartType("nat")
    private final int[] sinceOrder = new int[BoilerConstants.PUMP_COUNT + 1];

    private final boolean[] orderTarget = new boolean[BoilerConstants.PUMP_COUNT + 1];

    // ---- STOP counter (SB-V10, SB-Beh23) ----
    @RoboChartType("nat")
    private int stopCount;

    // ---- transmission verdict for the current cycle (SB-FR5) ----
    private boolean transmissionBroken;

    public Sensor(StatusRegister register) {
        this.register = register;
        this.waterLevel = 0.0;
        this.steamRate = 0.0;
        this.lastAcceptedLevel = 0.0;
        this.lastAcceptedSteam = 0.0;
        this.stopCount = 0;
    }

    // ------------------------------------------------------------------
    // Cycle ingestion
    // ------------------------------------------------------------------

    /**
     * Ingests the incoming batch of one transmission (all messages of the
     * cycle, received simultaneously, SB-V3): checks transmission integrity
     * (SB-FR5), advances the STOP counter (SB-V10), latches the protocol
     * handshake messages (SB-Beh2, SB-Beh7), processes repair notifications
     * and failure acknowledgements (SB-FR6, SB-FR7), and runs the four unit
     * failure detections (SB-FR1..SB-FR4).
     */
    public void ingest(TransmissionData batch) {
        // SB-FR5 — indispensable data messages must be present; aberrant
        // messages are a transmission failure.
        this.transmissionBroken = batch.aberrant()
                || !batch.levelPresent()
                || !batch.steamPresent()
                || !batch.pump1().statePresent() || !batch.pump1().flowPresent()
                || !batch.pump2().statePresent() || !batch.pump2().flowPresent()
                || !batch.pump3().statePresent() || !batch.pump3().flowPresent()
                || !batch.pump4().statePresent() || !batch.pump4().flowPresent();
        if (this.transmissionBroken) {
            return;
        }

        // SB-V10 — successive-STOP counter.
        if (batch.stopRequest()) {
            this.stopCount = this.stopCount + 1;
        } else {
            this.stopCount = 0;
        }

        // SB-Beh2 / SB-Beh7 — handshake latches.
        if (batch.waiting()) {
            this.plantAnnounced = true;
        }
        if (batch.unitsReady()) {
            this.unitsReadySeen = true;
        }

        // SB-FR7 — repair notifications: unit sound again, acknowledgement due.
        boolean levelJustRepaired = batch.levelRepaired();
        boolean steamJustRepaired = batch.steamRepaired();
        if (levelJustRepaired) {
            register.levelRepaired();
        }
        if (steamJustRepaired) {
            register.steamRepaired();
        }
        ingestPumpRepairs(1, batch.pump1());
        ingestPumpRepairs(2, batch.pump2());
        ingestPumpRepairs(3, batch.pump3());
        ingestPumpRepairs(4, batch.pump4());

        // SB-FR6 — acknowledgements of our failure detections.
        if (batch.levelFailureAck()) {
            register.levelFailureAcked();
        }
        if (batch.steamFailureAck()) {
            register.steamFailureAcked();
        }

        // SB-FR4 — steam device validity (static range, then dynamics).
        double reportedSteam = batch.steam();
        if (register.steamSound()) {
            boolean steamStaticOk = reportedSteam >= 0.0 && reportedSteam <= BoilerConstants.W;
            boolean steamDynamicOk = true;
            if (this.hasAcceptedSteam && !steamJustRepaired) {
                double maxUp = this.lastAcceptedSteam
                        + BoilerConstants.U1 * BoilerConstants.CYCLE_SECONDS;
                double maxDown = this.lastAcceptedSteam
                        - BoilerConstants.U2 * BoilerConstants.CYCLE_SECONDS;
                steamDynamicOk = reportedSteam <= maxUp && reportedSteam >= maxDown;
            }
            if (!steamStaticOk || !steamDynamicOk) {
                register.steamFailed();
            }
        }
        if (register.steamSound()) {
            this.steamRate = reportedSteam;
            this.lastAcceptedSteam = reportedSteam;
            this.hasAcceptedSteam = true;
        }

        // SB-Beh3 — once the plant has announced itself, the very first
        // steam reading must be zero, otherwise the steam device is judged
        // defective (initialization-specific check).
        if (this.plantAnnounced && !this.initialSteamChecked) {
            this.initialSteamChecked = true;
            if (reportedSteam != 0.0) {
                this.initialSteamDefect = true;
                register.steamFailed();
            }
        }

        // SB-FR3 — level device validity (static range, then dynamics).
        double reportedLevel = batch.level();
        if (register.levelSound()) {
            boolean levelStaticOk = reportedLevel >= 0.0 && reportedLevel <= BoilerConstants.C;
            boolean levelDynamicOk = true;
            if (this.hasAcceptedLevel && !levelJustRepaired) {
                double maxRise = maxPumpInPerCycle();
                double maxFall = maxSteamOutPerCycle();
                levelDynamicOk = reportedLevel <= this.lastAcceptedLevel + maxRise
                        && reportedLevel >= this.lastAcceptedLevel - maxFall;
            }
            if (!levelStaticOk || !levelDynamicOk) {
                register.levelFailed();
            }
        }
        if (register.levelSound()) {
            this.waterLevel = reportedLevel;
            this.lastAcceptedLevel = reportedLevel;
            this.hasAcceptedLevel = true;
        }

        // SB-FR1 / SB-FR2 — pump and pump-controller failure detection.
        ingestPumpState(1, batch.pump1());
        ingestPumpState(2, batch.pump2());
        ingestPumpState(3, batch.pump3());
        ingestPumpState(4, batch.pump4());
    }

    private void ingestPumpRepairs(int pumpId, PumpReport report) {
        if (report.pumpRepaired()) {
            register.pumpRepaired(pumpId);
        }
        if (report.controlRepaired()) {
            register.controlRepaired(pumpId);
        }
        if (report.pumpFailureAck()) {
            register.pumpFailureAcked(pumpId);
        }
        if (report.controlFailureAck()) {
            register.controlFailureAcked(pumpId);
        }
    }

    private void ingestPumpState(int pumpId, PumpReport report) {
        boolean reportedOn = report.running();
        boolean reportedFlow = report.flows();

        if (register.pumpSound(pumpId)) {
            if (this.sinceOrder[pumpId] == 1) {
                // SB-FR1 (first clause) — the transmission following an order
                // must show the ordered state.
                if (reportedOn != this.orderTarget[pumpId]) {
                    register.pumpFailed(pumpId);
                }
                this.expectedOn[pumpId] = this.orderTarget[pumpId];
            } else if (this.sinceOrder[pumpId] == 0
                    && reportedOn != this.expectedOn[pumpId]) {
                // SB-FR1 (second clause) — spontaneous state change.
                register.pumpFailed(pumpId);
            }
        }
        if (!register.pumpSound(pumpId)) {
            // Track the plant's reported state so a later repair resyncs.
            this.expectedOn[pumpId] = reportedOn;
        }

        if (register.controlSound(pumpId)) {
            if (this.sinceOrder[pumpId] == 2) {
                // SB-FR2 (first clause) — at the second transmission after the
                // order the flow must have come or ceased, provided the pump
                // itself is known to work (SB-Beh25 latency already elapsed).
                if (register.pumpSound(pumpId)
                        && reportedFlow != this.orderTarget[pumpId]) {
                    register.controlFailed(pumpId);
                }
            } else if (this.sinceOrder[pumpId] == 0
                    && reportedFlow != this.prevFlow[pumpId]
                    && reportedOn == this.expectedOn[pumpId]) {
                // SB-FR2 (second clause) — spontaneous flow-report change.
                register.controlFailed(pumpId);
            }
        }

        if (this.sinceOrder[pumpId] == 1) {
            this.sinceOrder[pumpId] = 2;
        } else if (this.sinceOrder[pumpId] == 2) {
            this.sinceOrder[pumpId] = 0;
        }

        this.pumpOn[pumpId] = reportedOn;
        this.pumpFlow[pumpId] = reportedFlow;
        this.prevFlow[pumpId] = reportedFlow;
    }

    /**
     * Records a state-changing pump order issued by the program this cycle
     * (SB-Beh5, SB-Beh10). Idempotent re-orders (ordering a pump into the
     * state it already has, or repeating a pending order) are ignored so the
     * SB-FR1/SB-FR2 check windows are not perpetually reset.
     */
    public void notePumpOrder(@RoboChartType("nat") int pumpId, boolean turnOn) {
        if (this.sinceOrder[pumpId] > 0 && this.orderTarget[pumpId] == turnOn) {
            return;
        }
        if (this.sinceOrder[pumpId] == 0 && this.expectedOn[pumpId] == turnOn) {
            return;
        }
        this.orderTarget[pumpId] = turnOn;
        this.sinceOrder[pumpId] = 1;
    }

    // ------------------------------------------------------------------
    // Controller-facing queries (safe defaults, no sentinels)
    // ------------------------------------------------------------------

    /** Latest accepted water level q (litre). SB-V5. */
    @RoboChartType("real")
    public double waterLevel() {
        return waterLevel;
    }

    /** Latest accepted steam rate v (litre/sec). SB-V6. */
    @RoboChartType("real")
    public double steamRate() {
        return steamRate;
    }

    /** STEAM_BOILER_WAITING received (SB-Beh2). */
    public boolean plantAnnounced() {
        return plantAnnounced;
    }

    /** PHYSICAL_UNITS_READY received (SB-Beh7, SB-Beh8). */
    public boolean unitsReadySeen() {
        return unitsReadySeen;
    }

    /** The SB-Beh3 start-up steam check failed. */
    public boolean initialSteamDefect() {
        return initialSteamDefect;
    }

    /** Successive-STOP count (SB-V10, SB-Beh23). */
    @RoboChartType("nat")
    public int stopCount() {
        return stopCount;
    }

    /** This cycle's transmission was aberrant or incomplete (SB-FR5). */
    public boolean transmissionBroken() {
        return transmissionBroken;
    }

    /** The level measuring device is currently believed out of order. */
    public boolean levelDeviceBroken() {
        return !register.levelSound();
    }

    /** The steam measuring device is currently believed out of order. */
    public boolean steamDeviceBroken() {
        return !register.steamSound();
    }

    /** Some pump controller is currently believed out of order (SB-Beh21). */
    public boolean anyControlUnitBroken() {
        return register.anyControlFailed();
    }

    /** Some physical unit is currently believed out of order. */
    public boolean anyUnitBroken() {
        return register.anyPumpFailed() || register.anyControlFailed()
                || !register.levelSound() || !register.steamSound();
    }

    /** Some unit other than the level device is out of order (SB-Beh12). */
    public boolean anyNonLevelUnitBroken() {
        return register.anyPumpFailed() || register.anyControlFailed()
                || !register.steamSound();
    }

    /** Every physical unit is currently believed sound (SB-Beh8, SB-Beh16, SB-Beh20). */
    public boolean allUnitsSound() {
        return !anyUnitBroken();
    }

    // ------------------------------------------------------------------
    // Worst-case per-cycle water balance (SB-V8, SB-Beh13, SB-Beh19, SB-Beh25)
    // ------------------------------------------------------------------

    /**
     * The reference lower level bound: the accepted reading when the level
     * device is sound, otherwise the supplied estimate carried over from the
     * previous cycle (SB-V8).
     */
    @RoboChartType("real")
    public double baseLevelLow(@RoboChartType("real") double carried) {
        if (register.levelSound() && this.hasAcceptedLevel) {
            return this.waterLevel;
        }
        if (carried < 0.0) {
            return 0.0;
        }
        return carried;
    }

    /**
     * The reference upper level bound: the accepted reading when the level
     * device is sound, otherwise the supplied estimate carried over from the
     * previous cycle (SB-V8).
     */
    @RoboChartType("real")
    public double baseLevelHigh(@RoboChartType("real") double carried) {
        if (register.levelSound() && this.hasAcceptedLevel) {
            return this.waterLevel;
        }
        if (carried > BoilerConstants.C) {
            return BoilerConstants.C;
        }
        return carried;
    }

    /**
     * Maximal litres of water that can leave as steam during one cycle:
     * the current rate accelerated at the maximal gradient U1, capped at W
     * (SB-DM2, SB-Beh13).
     */
    @RoboChartType("real")
    public double maxSteamOutPerCycle() {
        double projected = this.steamRate
                + BoilerConstants.U1 * BoilerConstants.CYCLE_SECONDS;
        if (projected > BoilerConstants.W) {
            projected = BoilerConstants.W;
        }
        return projected * BoilerConstants.CYCLE_SECONDS;
    }

    /**
     * Minimal litres of water that must leave as steam during one cycle:
     * the current rate decelerated at the maximal gradient U2, floored at 0
     * (SB-DM2).
     */
    @RoboChartType("real")
    public double minSteamOutPerCycle() {
        double projected = this.steamRate
                - BoilerConstants.U2 * BoilerConstants.CYCLE_SECONDS;
        if (projected < 0.0) {
            projected = 0.0;
        }
        return projected * BoilerConstants.CYCLE_SECONDS;
    }

    /**
     * Litres of water guaranteed to be poured by the pumps during one cycle:
     * only pumps confirmed flowing by a sound controller count; a pump
     * ordered on but not yet confirmed contributes nothing (SB-Beh25).
     */
    @RoboChartType("real")
    public double minPumpInPerCycle() {
        double total = 0.0;
        for (int i = 1; i <= BoilerConstants.PUMP_COUNT; i++) {
            if (this.pumpFlow[i] && register.controlSound(i)) {
                total = total + BoilerConstants.P * BoilerConstants.CYCLE_SECONDS;
            }
        }
        return total;
    }

    /**
     * Maximal litres of water the pumps might pour during one cycle: any
     * pump reported on, ordered on, or out of order (possibly stuck on)
     * contributes its full nominal capacity (SB-Beh25, mapping-note
     * worst-case convention).
     */
    @RoboChartType("real")
    public double maxPumpInPerCycle() {
        double total = 0.0;
        for (int i = 1; i <= BoilerConstants.PUMP_COUNT; i++) {
            boolean mightPour = this.pumpOn[i]
                    || (this.sinceOrder[i] > 0 && this.orderTarget[i])
                    || !register.pumpSound(i);
            if (mightPour) {
                total = total + BoilerConstants.P * BoilerConstants.CYCLE_SECONDS;
            }
        }
        return total;
    }

    /**
     * Guaranteed current inflow contribution of pump n (litre/sec): P when
     * the pump is confirmed flowing by a sound controller, 0 otherwise
     * (SB-V7 derivation).
     */
    @RoboChartType("real")
    public double pumpInflow(@RoboChartType("nat") int pumpId) {
        if (this.pumpFlow[pumpId] && register.controlSound(pumpId)) {
            return BoilerConstants.P;
        }
        return 0.0;
    }

    public StatusRegister register() {
        return register;
    }
}
