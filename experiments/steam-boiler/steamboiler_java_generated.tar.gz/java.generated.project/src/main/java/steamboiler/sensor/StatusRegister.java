package steamboiler.sensor;

import steamboiler.constants.BoilerConstants;

/**
 * Per-unit soundness and announcement bookkeeping (SB-V9): for each of the
 * four pumps, the four pump controllers, the level device, and the steam
 * device, whether the unit is currently believed sound, whether a failure
 * detection still awaits acknowledgement (SB-FR6), and whether a repair
 * acknowledgement is owed (SB-FR7). Pump indices are 1-based (1..4).
 */
public final class StatusRegister {

    private final boolean[] pumpSound = new boolean[BoilerConstants.PUMP_COUNT + 1];
    private final boolean[] pumpDetectionPending = new boolean[BoilerConstants.PUMP_COUNT + 1];
    private final boolean[] pumpRepairAckDue = new boolean[BoilerConstants.PUMP_COUNT + 1];
    private final boolean[] controlSound = new boolean[BoilerConstants.PUMP_COUNT + 1];
    private final boolean[] controlDetectionPending = new boolean[BoilerConstants.PUMP_COUNT + 1];
    private final boolean[] controlRepairAckDue = new boolean[BoilerConstants.PUMP_COUNT + 1];

    private boolean levelSound;
    private boolean levelDetectionPending;
    private boolean levelRepairAckDue;
    private boolean steamSound;
    private boolean steamDetectionPending;
    private boolean steamRepairAckDue;

    public StatusRegister() {
        for (int i = 1; i <= BoilerConstants.PUMP_COUNT; i++) {
            this.pumpSound[i] = true;
            this.controlSound[i] = true;
        }
        this.levelSound = true;
        this.steamSound = true;
    }

    // ---- failure detections (SB-FR1..FR4, FR6) ----

    public void pumpFailed(int pumpId) {
        this.pumpSound[pumpId] = false;
        this.pumpDetectionPending[pumpId] = true;
    }

    public void controlFailed(int pumpId) {
        this.controlSound[pumpId] = false;
        this.controlDetectionPending[pumpId] = true;
    }

    public void levelFailed() {
        this.levelSound = false;
        this.levelDetectionPending = true;
    }

    public void steamFailed() {
        this.steamSound = false;
        this.steamDetectionPending = true;
    }

    // ---- failure acknowledgements (SB-FR6) ----

    public void pumpFailureAcked(int pumpId) {
        this.pumpDetectionPending[pumpId] = false;
    }

    public void controlFailureAcked(int pumpId) {
        this.controlDetectionPending[pumpId] = false;
    }

    public void levelFailureAcked() {
        this.levelDetectionPending = false;
    }

    public void steamFailureAcked() {
        this.steamDetectionPending = false;
    }

    // ---- repairs (SB-FR7) ----

    public void pumpRepaired(int pumpId) {
        this.pumpSound[pumpId] = true;
        this.pumpDetectionPending[pumpId] = false;
        this.pumpRepairAckDue[pumpId] = true;
    }

    public void controlRepaired(int pumpId) {
        this.controlSound[pumpId] = true;
        this.controlDetectionPending[pumpId] = false;
        this.controlRepairAckDue[pumpId] = true;
    }

    public void levelRepaired() {
        this.levelSound = true;
        this.levelDetectionPending = false;
        this.levelRepairAckDue = true;
    }

    public void steamRepaired() {
        this.steamSound = true;
        this.steamDetectionPending = false;
        this.steamRepairAckDue = true;
    }

    public void clearPumpRepairAck(int pumpId) {
        this.pumpRepairAckDue[pumpId] = false;
    }

    public void clearControlRepairAck(int pumpId) {
        this.controlRepairAckDue[pumpId] = false;
    }

    public void clearLevelRepairAck() {
        this.levelRepairAckDue = false;
    }

    public void clearSteamRepairAck() {
        this.steamRepairAckDue = false;
    }

    // ---- queries ----

    public boolean pumpSound(int pumpId) {
        return pumpSound[pumpId];
    }

    public boolean controlSound(int pumpId) {
        return controlSound[pumpId];
    }

    public boolean levelSound() {
        return levelSound;
    }

    public boolean steamSound() {
        return steamSound;
    }

    public boolean pumpDetectionPending(int pumpId) {
        return pumpDetectionPending[pumpId];
    }

    public boolean controlDetectionPending(int pumpId) {
        return controlDetectionPending[pumpId];
    }

    public boolean levelDetectionPending() {
        return levelDetectionPending;
    }

    public boolean steamDetectionPending() {
        return steamDetectionPending;
    }

    public boolean pumpRepairAckDue(int pumpId) {
        return pumpRepairAckDue[pumpId];
    }

    public boolean controlRepairAckDue(int pumpId) {
        return controlRepairAckDue[pumpId];
    }

    public boolean levelRepairAckDue() {
        return levelRepairAckDue;
    }

    public boolean steamRepairAckDue() {
        return steamRepairAckDue;
    }

    /** Any of the four pumps currently believed out of order. */
    public boolean anyPumpFailed() {
        boolean any = false;
        for (int i = 1; i <= BoilerConstants.PUMP_COUNT; i++) {
            if (!pumpSound[i]) {
                any = true;
            }
        }
        return any;
    }

    /** Any of the four pump controllers currently believed out of order. */
    public boolean anyControlFailed() {
        boolean any = false;
        for (int i = 1; i <= BoilerConstants.PUMP_COUNT; i++) {
            if (!controlSound[i]) {
                any = true;
            }
        }
        return any;
    }
}
