package steamboiler.sensor;

import steamboiler.annotation.RoboChartType;

/**
 * One incoming transmission batch (SB-V3, SB-DM9): all messages of a cycle,
 * received simultaneously. Mandatory data messages (level, steam, the four
 * pump states and four pump-controller states) carry presence flags so the
 * Sensor layer can detect a transmission failure when one is missing
 * (SB-FR5). {@code aberrant} models the arrival of a message whose presence
 * is aberrant.
 */
public record TransmissionData(
        boolean stopRequest,
        boolean waiting,
        boolean unitsReady,
        boolean levelPresent,
        @RoboChartType("real") double level,
        boolean steamPresent,
        @RoboChartType("real") double steam,
        PumpReport pump1,
        PumpReport pump2,
        PumpReport pump3,
        PumpReport pump4,
        boolean levelRepaired,
        boolean steamRepaired,
        boolean levelFailureAck,
        boolean steamFailureAck,
        boolean aberrant) {

    /** A nominal transmission carrying only the mandatory data messages. */
    public static TransmissionData nominal(
            @RoboChartType("real") double level,
            @RoboChartType("real") double steam,
            PumpReport pump1,
            PumpReport pump2,
            PumpReport pump3,
            PumpReport pump4) {
        return new TransmissionData(false, false, false, true, level, true, steam,
                pump1, pump2, pump3, pump4, false, false, false, false, false);
    }
}
