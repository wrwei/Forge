Written by me from sranger_requirement_all.txt (SHA-256 above) alone; I did not consult the FORGE repository, any implementation, or any verification output for SRanger; interface assumptions are noted inline.

Source SHA-256: `5327a40a8356fb4f0f47beeaa42d32f88a4727b53322a963e67b9821b43e297e`.

The hash was checked before reading the file. The file contains 23 distinct SR- requirement entries and no LRE- or SB- prefixes. No SRanger verification output appears in the conversation context available to me, and none was accessed during this work. I cannot assess exposure in unavailable prior conversations. Only the supplied requirements and files newly authored for this deliverable were read for SRanger; local Java/JUnit tooling was used for compilation checks.

The suite is in [SrangerRequirementsTest.java](src/test/java/experiment/sranger/SrangerRequirementsTest.java). The assumed interface is in [SrangerTestAdapter.java](src/test/java/experiment/sranger/SrangerTestAdapter.java). The [coverage table](COVERAGE.md) accounts for all 23 entries, including partial coverage and requirements outside this controller boundary.

To integrate, supply a public, no-argument class implementing `SrangerTestAdapter` on the test classpath. Bind it to the actual plain Java controller, and supply that controller through your normal sources or dependency. Use Java 17 or later and run:

```sh
mvn -Dsranger.adapter=your.package.YourSrangerAdapter test
```

No controller implementation or reference model is bundled. A missing adapter causes an explicit setup failure, rather than a skipped or vacuously passing suite. Adapt the harness to the tests. Preserve the tests and their assertions when comparing repair runs.

Interface choices, also documented inline:

- A1: Java `double` values represent finite real quantities; distances are metres and time is seconds. Sensor samples and input event delivery are independently controllable. The test sensor is an environmental stub, not evidence that a production Sensor implements its own contract.
- A2: observe every actual `Move(lv, av)` event, including startup, in order. The recorder retains the full history. It must not infer events from modes or merge identical commands. This checks observable entry actions and the absence of Move emissions on tick self-transitions.
- A3: inject monotonic virtual time. Tests use exact binary values and adjacent representable values at guard boundaries; they never sleep or use approximate timeout assertions. A lower-resolution production clock needs an appropriate controllable time seam to run these boundary tests.
- A4: construction accepts fixed configuration values, in addition to a separate construction path that uses the controller's own defaults. Tests supply positive configurations and exercise them across repeated cycles. Invalid configurations are unspecified and are not tested.
- A5: expose actual mode through a read-only observation. The three adapter enum values name observations; enumerating this enum would not establish that the implementation has exactly three internal modes, so the suite does not make that assertion.
- A6: `runUntilIdle()` drives the controller's own due timers, queued work, or autonomous evaluation at the current virtual time without delivering any input event. It must not implement a missing timeout guard, transition or timer reset. If the production boundary cannot expose this capability, report SR-Beh5's autonomous behavior as untested; replacing this operation with `tick()` changes the experiment.
- A7: teardown may release resources; assertions finish before teardown. Each test invocation uses a fresh controller. Commands and mode observations must be settled before returning from `runUntilIdle()`.
- A8: attach the sensor, time source and output receiver before starting the controller, so initialization's forward command is captured. `startDefault` must preserve the controller's own defaults.

Requirement interpretation and limits:

- SR-GP1 specifies `distance <= obstacleThreshold`, including equality. SR-Beh2 is read together with that guard. SR-DM3's phrase "crosses below" describes the external obstacle event source. Tests deliberately deliver an obstacle with above-threshold, equal and below-threshold readings to check the controller guard independently of that source.
- SR-Beh5 is autonomous. Its tests advance time and settle due work without any input, with the distance still near. SR-Beh7's no-action tick tests occur strictly before timeout; the file gives no ordering rule for an input coincident with the timeout.
- "Terminal" in SR-DM1/SR-FR3 is interpreted as absorbing: after entering Final and issuing its stop, further events or elapsed time do not re-enter a mode or emit further entry commands. Both shutdown paths are exercised, including shutdown with a pending turn timeout.
- No policy is assumed for obstacle events in Turning, simultaneous events, backwards time, invalid sensor readings, negative/zero configuration, restart after Final, or sensor framework crossing detection. These cases have no specified controller behavior in the source.
- Exact event counts check the observable entry action once per tested transition. A complete event history is needed: inspecting only the last command cannot detect unwanted repeated emissions. Internal transition counts, private-variable storage, hardware architecture, other hidden output channels and production Sensor/Actuator guarantees require other interfaces or inspection and remain outside this suite's evidential claims.

The suite's compilation and case-enumeration checks are recorded in [VALIDATION.md](VALIDATION.md). No SRanger behavior has been run or reported as passing.
