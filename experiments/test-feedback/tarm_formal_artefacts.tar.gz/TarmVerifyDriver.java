import forge.transformations.core.PhaseContext;
import forge.transformations.preflight.LintPhase;
import forge.transformations.t2m.T2mPhase;
import forge.transformations.m2m.TransformPhase;
import forge.transformations.m2t.DafnyPhase;
import forge.transformations.m2t.RctPhase;
import forge.transformations.m2t.IsabellePhase;

import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * T-arm verification driver: identical to the campaign's CampaignDriver
 * (T2M -> M2M -> Dafny/RCT/Isabelle) but with the pipeline's preflight
 * structural linter run FIRST, mirroring pipeline.yaml phase order
 * (preflight -> t2m -> m2m -> m2t/dafny_gen/isabelle_gen).
 *
 * Gating follows bridge._count_lint_errors: error-severity violations fail
 * preflight (exit 3, extraction not run); warnings pass.
 *
 * Usage: TarmVerifyDriver <javaSourceDir> <outputDir>
 */
public final class TarmVerifyDriver {
    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            System.err.println("usage: TarmVerifyDriver <javaSourceDir> <outputDir>");
            System.exit(2);
        }
        Map<String, Object> a = new HashMap<>();
        a.put("source", args[0]);
        a.put("output", args[1]);
        PhaseContext ctx = new PhaseContext(Path.of(args[1]), a);

        new LintPhase().run(ctx);       // preflight structural lint
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> viols = ctx.require("lint_violations", List.class);
        int errors = 0, warnings = 0;
        for (Map<String, Object> v : viols) {
            String sev = String.valueOf(v.get("severity"));
            if ("error".equals(sev)) errors++;
            else if ("warning".equals(sev)) warnings++;
        }
        System.out.println("TARM_LINT_ERRORS=" + errors);
        System.out.println("TARM_LINT_WARNINGS=" + warnings);
        if (errors > 0) {
            System.out.println("TARM_PREFLIGHT_REJECTED");
            System.exit(3);             // phase-1 failure: stop, do not extract
        }

        new T2mPhase().run(ctx);        // discovery + resolved values
        new TransformPhase().run(ctx);  // ETL -> RoboChart, constant_defaults.json
        new DafnyPhase().run(ctx);      // .dfy
        new RctPhase().run(ctx);        // .rct (reads constant_defaults.json)
        new IsabellePhase().run(ctx);   // isabelle/<Stm>_Beh.thy + ROOT
        System.out.println("TARM_VERIFY_DRIVER_OK");
    }
}
