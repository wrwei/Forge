package com.sranger.actuator;

import com.sranger.annotation.RoboChartType;
import com.sranger.event.Move;

/**
 * Receives Move commands from the controller and records the latest
 * issued linear / angular velocity. No other output channels exist.
 */
public class Actuator implements ActuatorPort {

    @RoboChartType("real")
    private double lastLinearVelocity;

    @RoboChartType("real")
    private double lastAngularVelocity;

    /**
     * Records the given Move command as the latest issued command.
     */
    @Override
    public void receive(Move move) {
        this.lastLinearVelocity = move.linearVelocity();
        this.lastAngularVelocity = move.angularVelocity();
    }

    /**
     * Returns the last commanded linear velocity, in m/s.
     */
    @Override
    public double lastLinearVelocity() {
        return lastLinearVelocity;
    }

    /**
     * Returns the last commanded angular velocity, in rad/s.
     */
    @Override
    public double lastAngularVelocity() {
        return lastAngularVelocity;
    }
}
