package com.sranger;

import com.sranger.actuator.Actuator;
import com.sranger.actuator.DifferentialDriveActuator;
import com.sranger.controller.SRangerController;
import com.sranger.event.InputEvent;
import com.sranger.sensor.IrDistanceSensor;
import com.sranger.sensor.Sensor;

/**
 * Demonstration entry point wiring together the SRanger sensor, actuator,
 * and controller.
 */
public final class Main {

    private Main() {
    }

    public static void main(String[] args) {
        Sensor sensor = new IrDistanceSensor();
        Actuator actuator = new DifferentialDriveActuator();
        SRangerController controller = new SRangerController(sensor, actuator);

        controller.step(new InputEvent.Tick());
        System.out.println("Mode after tick: " + controller.getCurrentMode());

        IrDistanceSensor irSensor = (IrDistanceSensor) sensor;
        irSensor.setDistance(0.2);
        controller.step(new InputEvent.Obstacle());
        System.out.println("Mode after obstacle: " + controller.getCurrentMode());

        controller.step(new InputEvent.EndTask());
        System.out.println("Mode after endTask: " + controller.getCurrentMode());
    }
}
