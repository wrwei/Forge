package com.sranger.actuator;

import com.sranger.event.OutputEvent;

/**
 * Records the last motor command issued by the controller.
 */
public interface Actuator {

    /**
     * Receives a Move command from the controller and stores it as the
     * latest issued command.
     *
     * @param command the linear / angular velocity command
     */
    void receive(OutputEvent.Move command);

    /**
     * @return the last commanded linear velocity, in metres per second
     */
    double getLastLinearVelocity();

    /**
     * @return the last commanded angular velocity, in radians per second
     */
    double getLastAngularVelocity();
}
