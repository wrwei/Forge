package com.sranger.actuator;

import com.sranger.annotation.RoboChartType;
import com.sranger.event.OutputEvent;

/**
 * Differential-drive actuator that stores the latest Move command issued
 * by the controller.
 */
public class DifferentialDriveActuator implements Actuator {

    @RoboChartType("real")
    private double lastLinearVelocity;

    @RoboChartType("real")
    private double lastAngularVelocity;

    @Override
    public void receive(OutputEvent.Move command) {
        this.lastLinearVelocity = command.linearVelocity();
        this.lastAngularVelocity = command.angularVelocity();
    }

    @Override
    public double getLastLinearVelocity() {
        return this.lastLinearVelocity;
    }

    @Override
    public double getLastAngularVelocity() {
        return this.lastAngularVelocity;
    }
}
