package com.sranger.controller;

/**
 * The operating modes of the SRanger controller.
 */
public enum Mode {
    /** Initial mode: the robot drives forward. */
    MOVING,
    /** The robot rotates in place. */
    TURNING,
    /** Terminal mode entered when the operator issues endTask. */
    FINAL
}
