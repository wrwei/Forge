package com.sranger.controller;

import com.sranger.actuator.Actuator;
import com.sranger.annotation.RoboChartType;
import com.sranger.event.InputEvent;
import com.sranger.event.OutputEvent;
import com.sranger.sensor.Sensor;

/**
 * Reactive state machine for the SRanger ground robot. Selects transitions
 * based on the input event, the IR distance reading, and the elapsed time
 * in the current mode.
 */
public class SRangerController {

    private final Sensor sensor;
    private final Actuator actuator;

    private Mode currentMode = Mode.MOVING;

    @RoboChartType("real")
    private double clockResetTime;

    /**
     * Creates the controller in its initial Moving mode and issues the
     * corresponding entry action.
     *
     * @param sensor   the IR distance sensor
     * @param actuator the differential-drive actuator
     */
    public SRangerController(Sensor sensor, Actuator actuator) {
        this.sensor = sensor;
        this.actuator = actuator;
        this.actuator.receive(new OutputEvent.Move(SRangerConstants.MOVE_VEL, 0));
    }

    /**
     * Processes one input event, applying event-triggered and autonomous
     * transitions for the current mode. Final is a terminal mode: once
     * entered, no further outer branch matches and the controller ignores
     * all subsequent events, per SR-FR3 / SR-Beh3 / SR-Beh6. Tick delivers
     * no action in either Moving or Turning (SR-Beh4, SR-Beh7); the mode
     * simply remains unchanged when no other guard in the mode's inner
     * chain matches.
     *
     * @param event the received input event
     */
    public void step(InputEvent event) {
        boolean obstacleDetected = this.sensor.distance() <= SRangerConstants.OBSTACLE_THRESHOLD;
        boolean turnDurationElapsed = (this.currentTimeSeconds() - this.clockResetTime) >= SRangerConstants.TURN_DURATION;

        if (this.currentMode == Mode.MOVING) {
            if (event instanceof InputEvent.EndTask) {
                this.currentMode = Mode.FINAL;
                this.actuator.receive(new OutputEvent.Move(0, 0));
            } else if (event instanceof InputEvent.Obstacle && obstacleDetected) {
                this.currentMode = Mode.TURNING;
                this.clockResetTime = this.currentTimeSeconds();
                this.actuator.receive(new OutputEvent.Move(0, SRangerConstants.TURN_VEL));
            }
        } else if (this.currentMode == Mode.TURNING) {
            if (event instanceof InputEvent.EndTask) {
                this.currentMode = Mode.FINAL;
                this.actuator.receive(new OutputEvent.Move(0, 0));
            } else if (turnDurationElapsed) {
                this.currentMode = Mode.MOVING;
                this.actuator.receive(new OutputEvent.Move(SRangerConstants.MOVE_VEL, 0));
            }
        }
    }

    private double currentTimeSeconds() {
        return System.nanoTime() / 1_000_000_000.0;
    }

    /**
     * @return the controller's current operating mode
     */
    public Mode getCurrentMode() {
        return this.currentMode;
    }

    /**
     * @return the timestamp, in seconds, of the most recent entry into Turning
     */
    public double getClockResetTime() {
        return this.clockResetTime;
    }
}
