package com.sranger.event;

/**
 * The set of input events the SRanger controller can receive.
 */
public sealed interface InputEvent {

    /** Emitted by the IR sensor framework when an obstacle is detected. */
    record Obstacle() implements InputEvent {
    }

    /** Delivered each control cycle by the system framework. */
    record Tick() implements InputEvent {
    }

    /** Emitted by the operator-level shutdown channel. */
    record EndTask() implements InputEvent {
    }
}
