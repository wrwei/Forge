package com.sranger.event;

import com.sranger.annotation.RoboChartType;

/**
 * The set of output events the SRanger controller can emit.
 */
public sealed interface OutputEvent {

    /**
     * A combined linear / angular velocity command sent to the
     * differential-drive layer.
     */
    record Move(@RoboChartType("real") double linearVelocity, @RoboChartType("real") double angularVelocity)
            implements OutputEvent {
    }
}
