package com.sranger.sensor;

import com.sranger.annotation.RoboChartType;

/**
 * Forward-facing IR distance sensor implementation.
 */
public class IrDistanceSensor implements Sensor {

    @RoboChartType("real")
    private static final double DEFAULT_DISTANCE = 1000.0;

    @RoboChartType("real")
    private double currentDistance = DEFAULT_DISTANCE;

    @Override
    public double distance() {
        return this.currentDistance;
    }

    /**
     * Updates the latest IR distance reading.
     *
     * @param value the new distance reading, in metres
     */
    public void setDistance(@RoboChartType("real") double value) {
        this.currentDistance = value;
    }
}
