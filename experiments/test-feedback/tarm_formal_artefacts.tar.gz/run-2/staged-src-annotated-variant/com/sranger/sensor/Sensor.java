package com.sranger.sensor;

/**
 * Exposes the latest IR distance reading available to the controller.
 */
public interface Sensor {

    /**
     * Returns the latest IR distance reading, in metres, non-negative.
     * When no reading is available, a large default value is returned so
     * that the obstacle-detection condition is not falsely triggered.
     *
     * @return the latest distance reading in metres
     */
    double distance();
}
