package com.sranger.controller;

import com.sranger.annotation.RoboChartType;

/**
 * Fixed configuration constants for the SRanger controller.
 */
public final class SRangerConstants {

    private SRangerConstants() {
    }

    /** Linear velocity command when Moving, in m/s. */
    @RoboChartType("real")
    static final double MOVE_VEL = 1.0;

    /** Angular velocity command when Turning, in rad/s. */
    @RoboChartType("real")
    static final double TURN_VEL = 2.0;

    /** IR-distance threshold for the obstacle-detection condition, in metres. */
    @RoboChartType("real")
    static final double OBSTACLE_THRESHOLD = 0.5;

    /** How long the controller remains in Turning before returning to Moving, in seconds. */
    @RoboChartType("real")
    static final double TURN_DURATION = 2.0;
}
