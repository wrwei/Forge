package com.sranger.sensor;

import com.sranger.annotation.RoboChartType;

/**
 * Exposes the latest IR distance reading available to the controller.
 */
public class Sensor {

    @RoboChartType("real")
    private static final double DEFAULT_DISTANCE = 1000.0;

    @RoboChartType("real")
    private double lastDistance = DEFAULT_DISTANCE;

    /**
     * Records a new IR distance reading, in metres. Negative readings are
     * ignored, leaving the previous reading (or the default) in place.
     */
    public void updateDistance(@RoboChartType("real") double value) {
        if (value >= 0.0) {
            this.lastDistance = value;
        }
    }

    /**
     * Returns the latest IR distance reading in metres, non-negative. When
     * no reading has ever been recorded, a large default value is returned
     * so the obstacle-detection condition is not falsely triggered.
     */
    @RoboChartType("real")
    public double distance() {
        return this.lastDistance;
    }
}
