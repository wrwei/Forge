# Adapter notes (harness-side, never sent to the LLM)

- run-1: adapter authored for com.sranger.* API; first compile failed on simple-name shadowing (SrangerTestAdapter.Sensor/Actuator member types shadow SUT imports) — fixed with fully-qualified SUT names. Harness-side only; never sent to the LLM.
