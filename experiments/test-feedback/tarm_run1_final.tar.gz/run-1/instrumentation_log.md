# Instrumented-environment seams applied to the generated tree

- Actuator: observer seam grafted (MoveObserver/setObserver/forward in receive)
- SRangerConstants: de-finalised + harnessReset/harnessConfigure grafted
- Clock: natively deterministic (setTime, no wall-clock) — no modification required
