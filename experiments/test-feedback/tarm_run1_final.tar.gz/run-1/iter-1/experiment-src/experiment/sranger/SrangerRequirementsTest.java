// Written by me from sranger_requirement_all.txt (SHA-256 above) alone; I did not consult the FORGE repository, any implementation, or any verification output for SRanger; interface assumptions are noted inline.
package experiment.sranger;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

import static experiment.sranger.SrangerTestAdapter.Mode.*;
import static org.junit.jupiter.api.Assertions.*;

public class SrangerRequirementsTest {
    private static SrangerTestAdapter adapter;

    @BeforeAll
    static void loadAdapter() throws ReflectiveOperationException {
        String name = System.getProperty("sranger.adapter");
        assertTrue(name != null && !name.isBlank(),
                "Integration required: supply -Dsranger.adapter=<public adapter class>. "
                + "No SRanger implementation or reference model is bundled.");
        adapter = Class.forName(name).asSubclass(SrangerTestAdapter.class)
                .getConstructor().newInstance();
    }

    private record Command(double linear, double angular) { }

    // Test doubles control the environment and record actual outputs. They
    // contain no transition model and are NOT the production Sensor/Actuator.
    private static final class Reading implements SrangerTestAdapter.Sensor {
        private double value = 16.0;
        @Override public double distance() { return value; }
    }

    private static final class ManualTime implements SrangerTestAdapter.Time {
        private double value;
        ManualTime(double initial) { value = initial; }
        @Override public double seconds() { return value; }
    }

    private static final class RecordingActuator implements SrangerTestAdapter.Actuator {
        private final List<Command> commands = new ArrayList<>();
        @Override public void move(double linear, double angular) {
            commands.add(new Command(linear, angular));
        }
    }

    private static final class Rig implements AutoCloseable {
        private final Reading sensor = new Reading();
        private final ManualTime time;
        private final RecordingActuator actuator = new RecordingActuator();
        private final SrangerTestAdapter.Controller controller;

        Rig(double initialTime, SrangerTestAdapter.Config config) {
            time = new ManualTime(initialTime);
            controller = config == null
                    ? adapter.startDefault(sensor, actuator, time)
                    : adapter.startConfigured(config, sensor, actuator, time);
            assertNotNull(controller, "The adapter must return the real controller boundary");
            controller.runUntilIdle();
        }

        void at(double seconds) {
            assertTrue(Double.isFinite(seconds) && seconds >= time.value,
                    "Test time must be finite and monotonic");
            time.value = seconds;
            controller.runUntilIdle(); // Deliberately no tick or other input.
        }

        void obstacleAtDistance(double distance) {
            sensor.value = distance;
            controller.obstacle();
            controller.runUntilIdle();
        }

        void tick() {
            controller.tick();
            controller.runUntilIdle();
        }

        void endTask() {
            controller.endTask();
            controller.runUntilIdle();
        }

        void expect(SrangerTestAdapter.Mode mode, Command... expected) {
            assertEquals(mode, controller.mode(), "Observed controller mode");
            assertEquals(expected.length, actuator.commands.size(),
                    "Complete Move history: missing, extra or repeated events");
            for (int i = 0; i < expected.length; i++) {
                Command actual = actuator.commands.get(i);
                // These values are configured constants or exact zeros, not
                // physical measurements. Delta 0 accepts either sign of zero.
                assertEquals(expected[i].linear(), actual.linear(), 0.0,
                        "Move[" + i + "] linear velocity");
                assertEquals(expected[i].angular(), actual.angular(), 0.0,
                        "Move[" + i + "] angular velocity");
            }
        }

        @Override public void close() { controller.close(); }
    }

    private static Rig defaults(double initialTime) { return new Rig(initialTime, null); }
    private static Command forward() { return new Command(1.0, 0.0); }
    private static Command turn() { return new Command(0.0, 2.0); }
    private static Command stop() { return new Command(0.0, 0.0); }

    @Test
    @DisplayName("SR-Beh1 / SR-DM1 / SR-DM2 / SR-FR1 / SR-DM4: startup is Moving and emits default forward command")
    void sr_beh1_startupIsMovingWithForwardCommand() {
        try (Rig r = defaults(7.0)) {
            r.expect(MOVING, forward());
        }
    }

    static Stream<Double> nearDistances() {
        return Stream.of(0.0, Math.nextDown(0.5), 0.5);
    }

    @ParameterizedTest(name = "distance={0}")
    @MethodSource("nearDistances")
    @DisplayName("SR-GP1 / SR-Beh2 / SR-FR2 / SR-DM2: obstacle at or below default threshold starts turning")
    void sr_gp1_obstacleAtOrBelowThresholdEntersTurning(double distance) {
        // SR-GP1 explicitly includes equality. SR-DM3's 'crosses below'
        // describes the external event source, not a stricter controller guard.
        try (Rig r = defaults(13.0)) {
            r.obstacleAtDistance(distance);
            r.expect(TURNING, forward(), turn());
        }
    }

    static Stream<Double> farDistances() {
        return Stream.of(Math.nextUp(0.5), 1.0, 1_000_000.0);
    }

    @ParameterizedTest(name = "distance={0}")
    @MethodSource("farDistances")
    @DisplayName("SR-GP1 / SR-Beh2 / SR-DM2: obstacle above default threshold fails the guard")
    void sr_gp1_obstacleAboveThresholdKeepsMoving(double distance) {
        // Inject the event independently of the reading to exercise the guard;
        // no claim is made that the physical sensor emits this combination.
        try (Rig r = defaults(13.0)) {
            r.obstacleAtDistance(distance);
            r.expect(MOVING, forward());
        }
    }

    @Test
    @DisplayName("SR-SF1 / SR-ARCH2 / SR-GP1: each obstacle uses the latest sensor reading")
    void sr_sf1_obstacleUsesLatestReading() {
        try (Rig r = defaults(0.0)) {
            r.sensor.value = 0.0;
            r.sensor.value = 1.0;
            r.controller.obstacle();
            r.controller.runUntilIdle();
            r.expect(MOVING, forward());
            r.sensor.value = 0.0;
            r.controller.obstacle();
            r.controller.runUntilIdle();
            r.expect(TURNING, forward(), turn());
        }
    }

    @Test
    @DisplayName("SR-Beh2 / SR-DM3: a near reading alone does not deliver an obstacle event")
    void sr_beh2_nearReadingWithoutObstacleKeepsMoving() {
        try (Rig r = defaults(0.0)) {
            r.sensor.value = 0.0;
            r.at(32.0);
            r.expect(MOVING, forward());
        }
    }

    @ParameterizedTest(name = "distance={0}")
    @ValueSource(doubles = {0.0, 0.5, 16.0})
    @DisplayName("SR-Beh4 / SR-DM3: Moving tick has no mode change or output, even with a near reading")
    void sr_beh4_movingTickHasNoAction(double distance) {
        try (Rig r = defaults(0.0)) {
            r.sensor.value = distance;
            r.at(0.5);
            r.tick();
            r.expect(MOVING, forward());
            r.at(64.0);
            r.tick();
            r.tick();
            r.expect(MOVING, forward());
        }
    }

    static Stream<Double> beforeTimeout() {
        return Stream.of(0.0, 1.0, Math.nextDown(2.0));
    }

    @ParameterizedTest(name = "elapsedSeconds={0}")
    @MethodSource("beforeTimeout")
    @DisplayName("SR-GP2 / SR-Var1 / SR-DM2 / SR-Beh5: Turning persists strictly before default duration")
    void sr_gp2_beforeDurationRemainsTurning(double elapsed) {
        try (Rig r = defaults(0.0)) {
            r.obstacleAtDistance(0.0);
            r.expect(TURNING, forward(), turn());
            r.at(elapsed);
            r.expect(TURNING, forward(), turn());
        }
    }

    static Stream<Double> elapsedTimeout() {
        return Stream.of(2.0, Math.nextUp(2.0), 3.25);
    }

    @ParameterizedTest(name = "elapsedSeconds={0}")
    @MethodSource("elapsedTimeout")
    @DisplayName("SR-Beh5 / SR-GP2 / SR-FR1 / SR-DM2: timeout at or above duration returns to Moving without any input")
    void sr_beh5_atOrAfterDurationReturnsToMovingWithoutEvent(double elapsed) {
        try (Rig r = defaults(0.0)) {
            r.obstacleAtDistance(0.0);
            r.expect(TURNING, forward(), turn());
            // Leave distance at zero: the timeout is not guarded by distance,
            // and no new obstacle event has been delivered.
            r.at(elapsed);
            r.expect(MOVING, forward(), turn(), forward());
            r.controller.runUntilIdle();
            r.at(16.0);
            r.expect(MOVING, forward(), turn(), forward());
        }
    }

    @Test
    @DisplayName("SR-Var1 / SR-FR2 / SR-Beh2 / SR-GP2: turn duration starts at Turning entry, not controller startup")
    void sr_var1_clockResetUsesTurningEntryTime() {
        try (Rig r = defaults(64.0)) {
            r.at(65.25);
            r.obstacleAtDistance(0.0);
            r.expect(TURNING, forward(), turn());
            r.at(Math.nextDown(67.25));
            r.expect(TURNING, forward(), turn());
            r.at(67.25);
            r.expect(MOVING, forward(), turn(), forward());
        }
    }

    @Test
    @DisplayName("SR-Var1 / SR-FR2 / SR-Beh2 / SR-Beh5: every new Turning entry resets the timeout")
    void sr_var1_secondTurningEntryResetsClockAgain() {
        try (Rig r = defaults(30.25)) {
            r.obstacleAtDistance(0.0);
            r.expect(TURNING, forward(), turn());
            r.at(32.25);
            r.expect(MOVING, forward(), turn(), forward());
            r.at(100.5);
            r.obstacleAtDistance(0.5);
            r.expect(TURNING, forward(), turn(), forward(), turn());
            r.at(Math.nextDown(102.5));
            r.expect(TURNING, forward(), turn(), forward(), turn());
            r.at(102.5);
            r.expect(MOVING, forward(), turn(), forward(), turn(), forward());
        }
    }

    @ParameterizedTest(name = "distanceWhileTurning={0}")
    @ValueSource(doubles = {0.0, 0.5, 16.0})
    @DisplayName("SR-Beh7 / SR-Var1 / SR-DM3: Turning ticks before timeout have no action and do not reset the clock")
    void sr_beh7_turningTicksHaveNoActionOrClockReset(double distance) {
        try (Rig r = defaults(0.0)) {
            r.obstacleAtDistance(0.0);
            r.expect(TURNING, forward(), turn());
            r.sensor.value = distance;
            for (double t : new double[] {0.25, 0.75, 1.75}) {
                r.at(t);
                r.tick();
                r.expect(TURNING, forward(), turn());
            }
            r.at(2.0);
            r.expect(MOVING, forward(), turn(), forward());
        }
    }

    @ParameterizedTest(name = "distance={0}")
    @ValueSource(doubles = {0.0, 0.5, 16.0})
    @DisplayName("SR-Beh3 / SR-FR3 / SR-DM3: endTask in Moving enters Final and emits one stop regardless of distance")
    void sr_beh3_endTaskFromMovingStops(double distance) {
        try (Rig r = defaults(10.0)) {
            r.sensor.value = distance;
            r.endTask();
            r.expect(FINAL, forward(), stop());
        }
    }

    @ParameterizedTest(name = "elapsedSeconds={0}")
    @MethodSource("beforeTimeout")
    @DisplayName("SR-Beh6 / SR-FR3 / SR-DM3: endTask in Turning enters Final and emits one stop before timeout")
    void sr_beh6_endTaskFromTurningStops(double elapsed) {
        // Same-instant endTask/timeout priority is unspecified; stay below it.
        try (Rig r = defaults(0.0)) {
            r.obstacleAtDistance(0.0);
            r.expect(TURNING, forward(), turn());
            r.at(elapsed);
            r.endTask();
            r.expect(FINAL, forward(), turn(), stop());
        }
    }

    @ParameterizedTest(name = "terminateFromTurning={0}")
    @ValueSource(booleans = {false, true})
    @DisplayName("SR-DM1 / SR-FR3: Final is terminal under all inputs and later time, including a pending turn timeout")
    void sr_dm1_finalIsTerminal(boolean terminateFromTurning) {
        // 'Terminal' is interpreted as absorbing: no state re-entry or further
        // Move entry actions after the single stop on entry to Final.
        try (Rig r = defaults(0.0)) {
            if (terminateFromTurning) {
                r.obstacleAtDistance(0.0);
                r.expect(TURNING, forward(), turn());
            }
            r.endTask();
            Command[] history = terminateFromTurning
                    ? new Command[] {forward(), turn(), stop()}
                    : new Command[] {forward(), stop()};
            r.expect(FINAL, history);
            r.obstacleAtDistance(0.0);
            r.expect(FINAL, history);
            r.tick();
            r.expect(FINAL, history);
            r.endTask();
            r.expect(FINAL, history);
            r.at(2.0);
            r.expect(FINAL, history);
            r.at(128.0);
            r.tick();
            r.obstacleAtDistance(0.5);
            r.expect(FINAL, history);
        }
    }

    static Stream<SrangerTestAdapter.Config> configurations() {
        // Binary-exact positive values avoid decimal-representation ambiguity.
        return Stream.of(new SrangerTestAdapter.Config(0.25, 0.75, 1.25, 0.5),
                new SrangerTestAdapter.Config(3.0, 4.0, 0.125, 4.0));
    }

    @ParameterizedTest(name = "config={0}")
    @MethodSource("configurations")
    @DisplayName("SR-DM2 / SR-GP1 / SR-GP2 / SR-FR1 / SR-FR2: all four configured constants govern repeated motion cycles")
    void sr_dm2_configuredConstantsControlMotionAndRemainStable(SrangerTestAdapter.Config config) {
        Command moving = new Command(config.moveVel(), 0.0);
        Command turning = new Command(0.0, config.turnVel());
        try (Rig r = new Rig(16.0, config)) {
            r.expect(MOVING, moving);
            List<Command> history = new ArrayList<>(List.of(moving));
            for (double entryTime : new double[] {16.0, 32.0}) {
                r.at(entryTime);
                r.obstacleAtDistance(Math.nextUp(config.obstacleThreshold()));
                r.expect(MOVING, history.toArray(Command[]::new));
                r.obstacleAtDistance(config.obstacleThreshold());
                history.add(turning);
                r.expect(TURNING, history.toArray(Command[]::new));
                double deadline = entryTime + config.turnDuration();
                r.at(Math.nextDown(deadline));
                r.expect(TURNING, history.toArray(Command[]::new));
                r.at(deadline);
                history.add(moving);
                r.expect(MOVING, history.toArray(Command[]::new));
            }
        }
    }

    @ParameterizedTest(name = "config={0}")
    @MethodSource("configurations")
    @DisplayName("SR-FR3 / SR-Beh3 / SR-Beh6 / SR-DM4: stop uses zero linear and angular velocity with nondefault configuration")
    void sr_fr3_stopIsZeroWithConfiguredVelocities(SrangerTestAdapter.Config config) {
        Command moving = new Command(config.moveVel(), 0.0);
        Command turning = new Command(0.0, config.turnVel());
        try (Rig r = new Rig(0.0, config)) {
            r.endTask();
            r.expect(FINAL, moving, stop());
        }
        try (Rig r = new Rig(0.0, config)) {
            r.obstacleAtDistance(0.0);
            r.expect(TURNING, moving, turning);
            r.endTask();
            r.expect(FINAL, moving, turning, stop());
        }
    }
}
