// Written by me from sranger_requirement_all.txt (SHA-256 above) alone; I did not consult the FORGE repository, any implementation, or any verification output for SRanger; interface assumptions are noted inline.
package experiment.sranger;

/**
 * Boundary assumed by the tests; this is NOT a controller implementation.
 * Supply a public, no-argument implementation selected by -Dsranger.adapter=...
 * Translation, dependency injection and scheduling belong in that adapter;
 * guards, transitions, command generation and timer resets belong in the SUT.
 */
public interface SrangerTestAdapter {
    // SR-DM1: names used for observation, not evidence of the internal mode count.
    enum Mode { MOVING, TURNING, FINAL }

    // Assumption A1: finite Java doubles represent the real-valued quantities.
    // Samples and event deliveries are separate; changing a sample does not emit
    // an obstacle event. The external sensor framework is outside this boundary.
    @FunctionalInterface
    interface Sensor {
        double distance();
    }

    // Assumption A2: each actual advisory Move event calls this receiver once.
    // The adapter must preserve duplicates, zeros and order; never deduplicate
    // events or synthesize commands from mode observations.
    @FunctionalInterface
    interface Actuator {
        void move(double linearVelocity, double angularVelocity);
    }

    // Assumption A3: a monotonic, injectable time source in seconds.
    @FunctionalInterface
    interface Time {
        double seconds();
    }

    // Assumption A4: configuration can be supplied at construction; there is no
    // runtime reconfiguration. Tests use finite positive constants only.
    record Config(double moveVel, double turnVel,
                  double obstacleThreshold, double turnDuration) { }

    interface Controller extends AutoCloseable {
        // Assumption A5: read-only observation of the actual SUT mode. Do not
        // infer mode from motor commands; those observations are checked apart.
        Mode mode();

        // SR-DM3: one payload-free input delivery per call, in call order.
        void obstacle();
        void tick();
        void endTask();

        /**
         * Assumption A6: deterministically settle the SUT at Time.seconds().
         * Run its own due timers, queued work or no-input control evaluation.
         * Do not deliver tick, obstacle or endTask. Do not implement timeout
         * comparison, mode changes or timer resets in the adapter itself.
         * This operation lets SR-Beh5 be checked without an input event and
         * avoids wall-clock sleeps or arbitrary scheduling tolerances.
         */
        void runUntilIdle();

        // Assumption A7: teardown releases resources; assertions precede it.
        @Override
        default void close() { }
    }

    /**
     * Assumption A8: start a fresh controller using its OWN default constants.
     * Wire the receiver before initialization so the startup Move is observed.
     * Do not supply test-owned values as a substitute for the SUT's defaults.
     */
    Controller startDefault(Sensor sensor, Actuator actuator, Time time);

    /** Start a fresh controller with the supplied fixed configuration. */
    Controller startConfigured(Config config, Sensor sensor, Actuator actuator, Time time);
}
