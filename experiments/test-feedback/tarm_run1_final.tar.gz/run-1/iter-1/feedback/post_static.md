# Static analysis (SpotBugs 4.8.6) — FAILED

## Summary
SpotBugs 4.8.6 (default ruleset, -effort:default -low): 12 instance(s) total, 3 above the reference noise floor (13 instances at this threshold).

## Run history
- New this run: 3
- Recurring from previous run: 0
- Resolved since previous run: 0

## Issues
### Issue 1: EI_EXPOSE_REP2 — EI_EXPOSE_REP2 in com.sranger.controller.SRangerController

**Raw**
```
new com.sranger.controller.SRangerController(Sensor, Actuator, Clock) may expose internal representation by storing an externally mutable object into SRangerController.actuator
```

**Java trace**
  - Java: `SRangerController.java`:35 (<init>)
  - Requirement(s): SR-ARCH1, SR-ARCH2, SR-Beh1, SR-Beh2, SR-Beh3, SR-Beh4, SR-Beh5, SR-Beh6, SR-Beh7, SR-DC1, SR-FR1, SR-FR2, SR-FR3, SR-GP1, SR-GP2, SR-Var1

**Fix directive**
SpotBugs flags this construct above the recorded reference noise floor. Rework the flagged code so the detector no longer fires; do not suppress with annotations.

### Issue 2: EI_EXPOSE_REP2 — EI_EXPOSE_REP2 in com.sranger.controller.SRangerController

**Raw**
```
new com.sranger.controller.SRangerController(Sensor, Actuator, Clock) may expose internal representation by storing an externally mutable object into SRangerController.cycleClock
```

**Java trace**
  - Java: `SRangerController.java`:36 (<init>)
  - Requirement(s): SR-ARCH1, SR-ARCH2, SR-Beh1, SR-Beh2, SR-Beh3, SR-Beh4, SR-Beh5, SR-Beh6, SR-Beh7, SR-DC1, SR-FR1, SR-FR2, SR-FR3, SR-GP1, SR-GP2, SR-Var1

**Fix directive**
SpotBugs flags this construct above the recorded reference noise floor. Rework the flagged code so the detector no longer fires; do not suppress with annotations.

### Issue 3: UCF_USELESS_CONTROL_FLOW — UCF_USELESS_CONTROL_FLOW in com.sranger.controller.SRangerController

**Raw**
```
Useless control flow in com.sranger.controller.SRangerController.step(InputEvent)
```

**Java trace**
  - Java: `SRangerController.java`:71 (step)
  - Requirement(s): SR-Beh2, SR-Beh3, SR-Beh4, SR-Beh5, SR-Beh6, SR-Beh7, SR-DC1, SR-FR1, SR-FR2, SR-FR3, SR-GP1, SR-GP2

**Fix directive**
SpotBugs flags this construct above the recorded reference noise floor. Rework the flagged code so the detector no longer fires; do not suppress with annotations.

## Files to review
- SRangerController.java (requirements: SR-ARCH1, SR-ARCH2, SR-Beh1, SR-Beh2, SR-Beh3, SR-Beh4, SR-Beh5, SR-Beh6, SR-Beh7, SR-DC1, SR-FR1, SR-FR2, SR-FR3, SR-GP1, SR-GP2, SR-Var1)

## Next step
Read each issue above, follow the fix directive, edit the linked Java file, and re-run static analysis.
