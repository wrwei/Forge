package com.sranger.app;

import com.sranger.actuator.Actuator;
import com.sranger.controller.Clock;
import com.sranger.controller.SRangerController;
import com.sranger.event.EndTaskEvent;
import com.sranger.event.ObstacleEvent;
import com.sranger.event.TickEvent;
import com.sranger.sensor.Sensor;

/**
 * Demonstrates the SRanger controller reacting to a simple scripted
 * sequence of events.
 */
public final class SRangerDemo {

    private SRangerDemo() {
    }

    public static void main(String[] args) {
        var sensor = new Sensor();
        var actuator = new Actuator();
        var cycleClock = new Clock();
        var controller = new SRangerController(sensor, actuator, cycleClock);

        System.out.println("Initial mode: " + controller.currentMode());
        System.out.println("Initial command: lv=" + actuator.lastLinearVelocity() + " av=" + actuator.lastAngularVelocity());

        sensor.setDistance(0.3);
        controller.step(new ObstacleEvent());
        System.out.println("After obstacle: mode=" + controller.currentMode() + " lv=" + actuator.lastLinearVelocity() + " av=" + actuator.lastAngularVelocity());

        cycleClock.advance(2.5);
        controller.step(new TickEvent());
        System.out.println("After turn duration: mode=" + controller.currentMode() + " lv=" + actuator.lastLinearVelocity() + " av=" + actuator.lastAngularVelocity());

        controller.step(new EndTaskEvent());
        System.out.println("After endTask: mode=" + controller.currentMode() + " lv=" + actuator.lastLinearVelocity() + " av=" + actuator.lastAngularVelocity());
    }
}
