package com.sranger.controller;

import com.sranger.annotation.RoboChartType;

/**
 * Simulated clock providing the current time, in seconds, used to
 * time the Turning to Moving transition.
 */
public class Clock {

    @RoboChartType("real")
    private double currentTime = 0.0;

    /**
     * Returns the current time, in seconds.
     */
    public double now() {
        return currentTime;
    }

    /**
     * Advances the current time by the given number of seconds.
     */
    public void advance(@RoboChartType("real") double deltaSeconds) {
        this.currentTime = this.currentTime + deltaSeconds;
    }

    /**
     * Sets the current time directly, in seconds.
     */
    public void setTime(@RoboChartType("real") double value) {
        this.currentTime = value;
    }
}
