package com.sranger.controller;

/**
 * The three operating modes of the SRanger controller.
 */
public enum Mode {
    MOVING,
    TURNING,
    FINAL
}
