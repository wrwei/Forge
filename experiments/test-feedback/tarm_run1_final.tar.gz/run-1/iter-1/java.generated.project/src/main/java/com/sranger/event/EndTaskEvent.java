package com.sranger.event;

/**
 * Emitted by the operator-level shutdown channel to terminate the
 * controller into Final. Carries no payload.
 */
public record EndTaskEvent() implements InputEvent {
}
