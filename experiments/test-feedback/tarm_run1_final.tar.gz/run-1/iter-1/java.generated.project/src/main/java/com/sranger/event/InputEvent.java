package com.sranger.event;

/**
 * The input events the SRanger controller reacts to: obstacle
 * detection, the periodic tick, and the operator shutdown signal.
 */
public sealed interface InputEvent permits ObstacleEvent, TickEvent, EndTaskEvent {
}
