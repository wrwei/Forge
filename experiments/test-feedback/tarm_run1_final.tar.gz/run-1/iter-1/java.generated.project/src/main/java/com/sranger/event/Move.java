package com.sranger.event;

import com.sranger.annotation.RoboChartType;

/**
 * A combined linear / angular velocity command to the
 * differential-drive layer. Covers forward motion, turning in place
 * and stopping.
 */
public record Move(@RoboChartType("real") double linearVelocity, @RoboChartType("real") double angularVelocity) implements OutputEvent {
}
