package com.sranger.event;

/**
 * Emitted by the IR sensor framework when the distance reading
 * crosses below the obstacle threshold. Carries no payload.
 */
public record ObstacleEvent() implements InputEvent {
}
