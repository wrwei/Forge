package com.sranger.event;

/**
 * The single output event family emitted by the SRanger controller
 * towards the differential-drive layer.
 */
public sealed interface OutputEvent permits Move {
}
