package com.sranger.event;

/**
 * Delivered each control cycle by the system framework. Carries no
 * payload.
 */
public record TickEvent() implements InputEvent {
}
