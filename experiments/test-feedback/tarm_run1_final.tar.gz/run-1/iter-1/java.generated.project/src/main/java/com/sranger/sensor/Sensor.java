package com.sranger.sensor;

import com.sranger.annotation.RoboChartType;

/**
 * Exposes the latest IR distance reading used by the controller to
 * detect obstacles.
 */
public class Sensor {

    /** Large default distance so missing data never falsely triggers obstacle detection. */
    private static final double DEFAULT_DISTANCE = 1000.0;

    @RoboChartType("real")
    private double currentDistance = DEFAULT_DISTANCE;

    /**
     * Returns the latest IR distance reading, in metres, non-negative.
     */
    public double distance() {
        return currentDistance;
    }

    /**
     * Updates the latest IR distance reading.
     */
    public void setDistance(@RoboChartType("real") double value) {
        this.currentDistance = value;
    }
}
