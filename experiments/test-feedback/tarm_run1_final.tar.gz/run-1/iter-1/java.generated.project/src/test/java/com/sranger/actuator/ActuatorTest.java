package com.sranger.actuator;

import com.sranger.event.Move;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ActuatorTest {

    @Test
    void receiveStoresLastCommand() {
        var actuator = new Actuator();
        actuator.receive(new Move(1.0, 0.0));
        assertEquals(1.0, actuator.lastLinearVelocity());
        assertEquals(0.0, actuator.lastAngularVelocity());

        actuator.receive(new Move(0.0, 2.0));
        assertEquals(0.0, actuator.lastLinearVelocity());
        assertEquals(2.0, actuator.lastAngularVelocity());
    }
}
