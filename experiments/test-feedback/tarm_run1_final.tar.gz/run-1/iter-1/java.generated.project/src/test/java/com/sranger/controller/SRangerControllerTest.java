package com.sranger.controller;

import com.sranger.actuator.Actuator;
import com.sranger.event.EndTaskEvent;
import com.sranger.event.ObstacleEvent;
import com.sranger.event.TickEvent;
import com.sranger.sensor.Sensor;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SRangerControllerTest {

    private Sensor sensor;
    private Actuator actuator;
    private Clock cycleClock;
    private SRangerController controller;

    @BeforeEach
    void setUp() {
        sensor = new Sensor();
        actuator = new Actuator();
        cycleClock = new Clock();
        controller = new SRangerController(sensor, actuator, cycleClock);
    }

    @Test
    void startsInMovingAndIssuesMoveCommand() {
        assertEquals(Mode.MOVING, controller.currentMode());
        assertEquals(1.0, actuator.lastLinearVelocity());
        assertEquals(0.0, actuator.lastAngularVelocity());
    }

    @Test
    void tickInMovingStaysMoving() {
        controller.step(new TickEvent());
        assertEquals(Mode.MOVING, controller.currentMode());
    }

    @Test
    void obstacleInMovingTransitionsToTurning() {
        sensor.setDistance(0.2);
        controller.step(new ObstacleEvent());
        assertEquals(Mode.TURNING, controller.currentMode());
        assertEquals(0.0, actuator.lastLinearVelocity());
        assertEquals(2.0, actuator.lastAngularVelocity());
    }

    @Test
    void obstacleEventWithoutThresholdCrossedDoesNotTurn() {
        sensor.setDistance(5.0);
        controller.step(new ObstacleEvent());
        assertEquals(Mode.MOVING, controller.currentMode());
    }

    @Test
    void turnDurationElapsedReturnsToMoving() {
        sensor.setDistance(0.2);
        controller.step(new ObstacleEvent());
        cycleClock.advance(2.0);
        controller.step(new TickEvent());
        assertEquals(Mode.MOVING, controller.currentMode());
        assertEquals(1.0, actuator.lastLinearVelocity());
        assertEquals(0.0, actuator.lastAngularVelocity());
    }

    @Test
    void endTaskFromMovingGoesToFinal() {
        controller.step(new EndTaskEvent());
        assertEquals(Mode.FINAL, controller.currentMode());
        assertEquals(0.0, actuator.lastLinearVelocity());
        assertEquals(0.0, actuator.lastAngularVelocity());
    }

    @Test
    void endTaskFromTurningGoesToFinal() {
        sensor.setDistance(0.2);
        controller.step(new ObstacleEvent());
        controller.step(new EndTaskEvent());
        assertEquals(Mode.FINAL, controller.currentMode());
        assertEquals(0.0, actuator.lastLinearVelocity());
        assertEquals(0.0, actuator.lastAngularVelocity());
    }
}
