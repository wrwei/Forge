package com.sranger.sensor;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SensorTest {

    @Test
    void defaultDistanceIsLargeToAvoidFalseObstacleDetection() {
        var sensor = new Sensor();
        assertTrue(sensor.distance() > 100.0);
    }

    @Test
    void setDistanceUpdatesReading() {
        var sensor = new Sensor();
        sensor.setDistance(0.4);
        assertEquals(0.4, sensor.distance());
    }
}
