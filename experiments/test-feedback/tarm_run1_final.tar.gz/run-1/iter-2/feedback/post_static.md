# Static analysis (SpotBugs 4.8.6) — PASSED

## Summary
SpotBugs 4.8.6 (default ruleset, -effort:default -low): 9 instance(s) total, 0 above the reference noise floor (13 instances at this threshold).

## Run history
- New this run: 0
- Recurring from previous run: 0
- Resolved since previous run: 2

**Resolved issue titles**
- EI_EXPOSE_REP2 in com.sranger.controller.SRangerController
- UCF_USELESS_CONTROL_FLOW in com.sranger.controller.SRangerController

## Issues
None.

## Files to review
(none identified)

## Next step
Static analysis clean at the recorded threshold.
