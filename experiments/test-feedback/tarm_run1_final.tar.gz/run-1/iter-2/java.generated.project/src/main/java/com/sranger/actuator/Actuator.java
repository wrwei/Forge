package com.sranger.actuator;

import com.sranger.annotation.RoboChartType;
import com.sranger.event.Move;

/**
 * Receives Move commands from the controller and records the latest
 * issued linear / angular velocity. No other output channels exist.
 */
public class Actuator implements ActuatorPort {

    @RoboChartType("real")
    private double lastLinearVelocity;

    @RoboChartType("real")
    private double lastAngularVelocity;

    /** HARNESS INSTRUMENTATION (T-arm adapter): forwards every receive() to an
     *  observer so tests can see each Move (duplicates and order preserved).
     *  Storage behaviour unchanged. */
    public interface MoveObserver { void onMove(double lv, double av); }
    private MoveObserver observer;
    public void setObserver(MoveObserver o) { this.observer = o; }

    /**
     * Records the given Move command as the latest issued command.
     */
    @Override
    public void receive(Move move) {
        this.lastLinearVelocity = move.linearVelocity();
        this.lastAngularVelocity = move.angularVelocity();
        if (observer != null) observer.onMove(move.linearVelocity(), move.angularVelocity());
    }

    /**
     * Returns the last commanded linear velocity, in m/s.
     */
    @Override
    public double lastLinearVelocity() {
        return lastLinearVelocity;
    }

    /**
     * Returns the last commanded angular velocity, in rad/s.
     */
    @Override
    public double lastAngularVelocity() {
        return lastAngularVelocity;
    }
}
