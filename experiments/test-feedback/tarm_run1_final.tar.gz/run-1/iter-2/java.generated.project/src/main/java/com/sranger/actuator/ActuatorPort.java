package com.sranger.actuator;

import com.sranger.event.Move;

/**
 * Exposes the Actuator's command-receiving and inspection operations,
 * decoupled from the concrete Actuator implementation.
 */
public interface ActuatorPort {

    /**
     * Records the given Move command as the latest issued command.
     */
    void receive(Move move);

    /**
     * Returns the last commanded linear velocity, in m/s.
     */
    double lastLinearVelocity();

    /**
     * Returns the last commanded angular velocity, in rad/s.
     */
    double lastAngularVelocity();
}
