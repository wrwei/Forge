package com.sranger.controller;

/**
 * Exposes the current-time query used by the controller to time the
 * Turning to Moving transition, decoupled from the concrete Clock
 * implementation.
 */
public interface ClockPort {

    /**
     * Returns the current time, in seconds.
     */
    double now();
}
