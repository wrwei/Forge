package com.sranger.controller;

import com.sranger.actuator.ActuatorPort;
import com.sranger.annotation.RoboChartType;
import com.sranger.constants.SRangerConstants;
import com.sranger.event.EndTaskEvent;
import com.sranger.event.InputEvent;
import com.sranger.event.Move;
import com.sranger.event.ObstacleEvent;
import com.sranger.event.TickEvent;
import com.sranger.sensor.Sensor;

/**
 * Reactive state machine controlling the SRanger robot. Selects
 * transitions based on the input event, the IR distance, and the
 * elapsed time in the current mode.
 */
public class SRangerController {

    private Mode currentMode;

    @RoboChartType("real")
    private double clockResetTime;

    private final Sensor sensor;
    private final ActuatorPort actuator;
    private final ClockPort cycleClock;

    /**
     * Creates the controller, wiring it to the given sensor, actuator
     * and clock, and performs the Moving entry action on power-up.
     */
    public SRangerController(Sensor sensor, ActuatorPort actuator, ClockPort cycleClock) {
        this.sensor = sensor;
        this.actuator = actuator;
        this.cycleClock = cycleClock;
        this.currentMode = Mode.MOVING;
        this.clockResetTime = cycleClock.now();
        this.actuator.receive(new Move(SRangerConstants.MOVE_VEL, 0.0));
    }

    /**
     * Handles one control step, covering both event-triggered and
     * autonomous transitions.
     */
    public void step(InputEvent event) {
        boolean obstacleDetected = sensor.distance() <= SRangerConstants.OBSTACLE_THRESHOLD;
        boolean turnDurationElapsed = (cycleClock.now() - clockResetTime) >= SRangerConstants.TURN_DURATION;

        if (currentMode == Mode.MOVING) {
            if (event instanceof EndTaskEvent) {
                currentMode = Mode.FINAL;
                actuator.receive(new Move(0.0, 0.0));
            } else if (event instanceof ObstacleEvent && obstacleDetected) {
                currentMode = Mode.TURNING;
                clockResetTime = cycleClock.now();
                actuator.receive(new Move(0.0, SRangerConstants.TURN_VEL));
            } else if (event instanceof TickEvent) {
                currentMode = Mode.MOVING;
            }
        } else if (currentMode == Mode.TURNING) {
            if (event instanceof EndTaskEvent) {
                currentMode = Mode.FINAL;
                actuator.receive(new Move(0.0, 0.0));
            } else if (turnDurationElapsed) {
                currentMode = Mode.MOVING;
                actuator.receive(new Move(SRangerConstants.MOVE_VEL, 0.0));
            } else if (event instanceof TickEvent) {
                currentMode = Mode.TURNING;
            }
        } else if (currentMode == Mode.FINAL) {
            currentMode = Mode.FINAL;
        }
    }

    /**
     * Returns the current operating mode.
     */
    public Mode currentMode() {
        return currentMode;
    }

    /**
     * Returns the timestamp, in seconds, recorded when the controller
     * most recently entered Turning.
     */
    public double clockResetTime() {
        return clockResetTime;
    }
}
