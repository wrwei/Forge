# Adapter notes (harness-side, never sent to the LLM)

- run-2: adapter binds IrDistanceSensor/DifferentialDriveActuator/two-arg controller constructor; deterministic time via the controller-level seam (no Clock class in this tree).
