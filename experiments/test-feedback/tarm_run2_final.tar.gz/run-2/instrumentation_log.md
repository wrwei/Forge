# Instrumented-environment seams applied to the generated tree

- DifferentialDriveActuator: observer seam grafted
- SRangerConstants: de-finalised + harnessReset/harnessConfigure grafted
- SRangerController: deterministic-clock seam at currentTimeSeconds() (run declared no Clock class; single time-read point)
