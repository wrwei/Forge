// T-arm harness adapter (run 2): binds SrangerTestAdapter (frozen contract)
// to the generated com.sranger.* controller. Suite/assertions untouched.
// SUT types fully qualified to avoid shadowing by the contract's member types.
package experiment.sranger;

import com.sranger.controller.SRangerConstants;
import com.sranger.controller.SRangerController;
import com.sranger.event.InputEvent;

public final class SrangerAdapterImpl implements SrangerTestAdapter {

    private Controller start(SrangerTestAdapter.Sensor sensor,
                             SrangerTestAdapter.Actuator actuator,
                             Time time) {
        SRangerController.harnessSetTimeSeconds(time.seconds()); // injectable time (A3)
        final com.sranger.sensor.IrDistanceSensor sutSensor = new com.sranger.sensor.IrDistanceSensor();
        sutSensor.setDistance(sensor.distance());
        final com.sranger.actuator.DifferentialDriveActuator sutActuator =
                new com.sranger.actuator.DifferentialDriveActuator();
        // A2: forward every Move, preserving duplicates/zeros/order.
        sutActuator.setObserver(new com.sranger.actuator.DifferentialDriveActuator.MoveObserver() {
            @Override public void onMove(double lv, double av) { actuator.move(lv, av); }
        });
        // A8: receiver wired BEFORE construction so the startup Move is observed.
        final SRangerController sut = new SRangerController(sutSensor, sutActuator);

        return new Controller() {
            private void sync() {
                SRangerController.harnessSetTimeSeconds(time.seconds());
                sutSensor.setDistance(sensor.distance());
            }
            @Override public Mode mode() {
                com.sranger.controller.Mode m = sut.getCurrentMode();
                if (m == com.sranger.controller.Mode.MOVING) return Mode.MOVING;
                if (m == com.sranger.controller.Mode.TURNING) return Mode.TURNING;
                return Mode.FINAL;
            }
            @Override public void obstacle() { sync(); sut.step(new InputEvent.Obstacle()); }
            @Override public void tick()     { sync(); sut.step(new InputEvent.Tick()); }
            @Override public void endTask()  { sync(); sut.step(new InputEvent.EndTask()); }
            // A6: settle at Time.seconds() WITHOUT delivering an input event; a null
            // event traverses only guard-only branches (SUT's own autonomous logic).
            @Override public void runUntilIdle() { sync(); sut.step(null); }
        };
    }

    @Override
    public Controller startDefault(SrangerTestAdapter.Sensor s,
                                   SrangerTestAdapter.Actuator a, Time t) {
        SRangerConstants.harnessReset();                    // A8: SUT's own defaults
        return start(s, a, t);
    }

    @Override
    public Controller startConfigured(Config c, SrangerTestAdapter.Sensor s,
                                      SrangerTestAdapter.Actuator a, Time t) {
        SRangerConstants.harnessConfigure(c.moveVel(), c.turnVel(),
                c.obstacleThreshold(), c.turnDuration());
        return start(s, a, t);
    }
}
