# Static analysis (SpotBugs 4.8.6) — FAILED

## Summary
SpotBugs 4.8.6 (default ruleset, -effort:default -low): 9 instance(s) total, 4 above the reference noise floor (13 instances at this threshold).

## Run history
- New this run: 4
- Recurring from previous run: 0
- Resolved since previous run: 0

## Issues
### Issue 1: MS_PKGPROTECT — MS_PKGPROTECT in com.sranger.controller.SRangerConstants

**Raw**
```
com.sranger.controller.SRangerConstants.MOVE_VEL should be package protected
```

**Java trace**
  - Java: `SRangerConstants.java`:21
  - Requirement(s): SR-DM2

**Fix directive**
SpotBugs flags this construct above the recorded reference noise floor. Rework the flagged code so the detector no longer fires; do not suppress with annotations.

### Issue 2: MS_PKGPROTECT — MS_PKGPROTECT in com.sranger.controller.SRangerConstants

**Raw**
```
com.sranger.controller.SRangerConstants.OBSTACLE_THRESHOLD should be package protected
```

**Java trace**
  - Java: `SRangerConstants.java`:29
  - Requirement(s): SR-DM2

**Fix directive**
SpotBugs flags this construct above the recorded reference noise floor. Rework the flagged code so the detector no longer fires; do not suppress with annotations.

### Issue 3: MS_PKGPROTECT — MS_PKGPROTECT in com.sranger.controller.SRangerConstants

**Raw**
```
com.sranger.controller.SRangerConstants.TURN_DURATION should be package protected
```

**Java trace**
  - Java: `SRangerConstants.java`:33
  - Requirement(s): SR-DM2

**Fix directive**
SpotBugs flags this construct above the recorded reference noise floor. Rework the flagged code so the detector no longer fires; do not suppress with annotations.

### Issue 4: UCF_USELESS_CONTROL_FLOW — UCF_USELESS_CONTROL_FLOW in com.sranger.controller.SRangerController

**Raw**
```
Useless control flow in com.sranger.controller.SRangerController.step(InputEvent)
```

**Java trace**
  - Java: `SRangerController.java`:66 (step)
  - Requirement(s): SR-ARCH2, SR-Beh2, SR-Beh3, SR-Beh4, SR-Beh5, SR-Beh6, SR-Beh7, SR-DC1, SR-FR1, SR-FR2, SR-FR3, SR-GP1, SR-GP2

**Fix directive**
SpotBugs flags this construct above the recorded reference noise floor. Rework the flagged code so the detector no longer fires; do not suppress with annotations.

## Files to review
- SRangerConstants.java (requirements: SR-DM2)
- SRangerController.java (requirements: SR-ARCH2, SR-Beh2, SR-Beh3, SR-Beh4, SR-Beh5, SR-Beh6, SR-Beh7, SR-DC1, SR-FR1, SR-FR2, SR-FR3, SR-GP1, SR-GP2)

## Next step
Read each issue above, follow the fix directive, edit the linked Java file, and re-run static analysis.
