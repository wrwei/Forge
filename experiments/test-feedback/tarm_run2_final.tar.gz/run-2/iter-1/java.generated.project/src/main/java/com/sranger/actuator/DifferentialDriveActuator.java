package com.sranger.actuator;

import com.sranger.annotation.RoboChartType;
import com.sranger.event.OutputEvent;

/**
 * Differential-drive actuator that stores the latest Move command issued
 * by the controller.
 */
public class DifferentialDriveActuator implements Actuator {

    @RoboChartType("real")
    private double lastLinearVelocity;

    @RoboChartType("real")
    private double lastAngularVelocity;

    /** HARNESS INSTRUMENTATION (T-arm adapter): forwards every receive() to an
     *  observer so tests can see each Move (duplicates and order preserved).
     *  Storage behaviour unchanged. */
    public interface MoveObserver { void onMove(double lv, double av); }
    private MoveObserver observer;
    public void setObserver(MoveObserver o) { this.observer = o; }

    @Override
    public void receive(OutputEvent.Move command) {
        this.lastLinearVelocity = command.linearVelocity();
        this.lastAngularVelocity = command.angularVelocity();
        if (observer != null) observer.onMove(command.linearVelocity(), command.angularVelocity());
    }

    @Override
    public double getLastLinearVelocity() {
        return this.lastLinearVelocity;
    }

    @Override
    public double getLastAngularVelocity() {
        return this.lastAngularVelocity;
    }
}
