package com.sranger.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.sranger.actuator.Actuator;
import com.sranger.actuator.DifferentialDriveActuator;
import com.sranger.event.InputEvent;
import com.sranger.sensor.IrDistanceSensor;
import com.sranger.sensor.Sensor;
import org.junit.jupiter.api.Test;

class SRangerControllerTest {

    @Test
    void startsInMovingMode() {
        Sensor sensor = new IrDistanceSensor();
        Actuator actuator = new DifferentialDriveActuator();
        var controller = new SRangerController(sensor, actuator);

        assertEquals(Mode.MOVING, controller.getCurrentMode());
    }

    @Test
    void obstacleTransitionsMovingToTurning() {
        var sensor = new IrDistanceSensor();
        Actuator actuator = new DifferentialDriveActuator();
        var controller = new SRangerController(sensor, actuator);

        sensor.setDistance(0.1);
        controller.step(new InputEvent.Obstacle());

        assertEquals(Mode.TURNING, controller.getCurrentMode());
    }

    @Test
    void endTaskTransitionsToFinalFromMoving() {
        Sensor sensor = new IrDistanceSensor();
        Actuator actuator = new DifferentialDriveActuator();
        var controller = new SRangerController(sensor, actuator);

        controller.step(new InputEvent.EndTask());

        assertEquals(Mode.FINAL, controller.getCurrentMode());
    }

    @Test
    void tickInMovingKeepsMovingModeWhenNoObstacle() {
        Sensor sensor = new IrDistanceSensor();
        Actuator actuator = new DifferentialDriveActuator();
        var controller = new SRangerController(sensor, actuator);

        controller.step(new InputEvent.Tick());

        assertEquals(Mode.MOVING, controller.getCurrentMode());
    }
}
