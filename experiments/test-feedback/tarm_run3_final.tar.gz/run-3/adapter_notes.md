# Adapter notes (harness-side, never sent to the LLM)

- run-3: adapter implements the tree's own Clock interface deterministically; binds Sensor.updateDistance / Actuator / three-arg constructor.
