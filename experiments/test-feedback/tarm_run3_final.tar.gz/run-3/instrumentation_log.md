# Instrumented-environment seams applied to the generated tree

- Actuator: observer seam grafted
- SRangerConstants: de-finalised + harnessReset/harnessConfigure grafted
- Clock: tree declares a Clock interface with injectable implementations — adapter provides the deterministic clock; no SUT file modified
