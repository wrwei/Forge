// T-arm harness adapter (run 3): binds SrangerTestAdapter (frozen contract)
// to the generated com.sranger.* controller. Suite/assertions untouched.
// SUT types fully qualified to avoid shadowing by the contract's member types.
package experiment.sranger;

import com.sranger.controller.SRangerConstants;
import com.sranger.controller.SRangerController;
import com.sranger.event.EndTaskEvent;
import com.sranger.event.ObstacleEvent;
import com.sranger.event.TickEvent;

public final class SrangerAdapterImpl implements SrangerTestAdapter {

    /** Deterministic Clock implementation (A3): returns exactly the injected value. */
    private static final class HarnessClock implements com.sranger.controller.Clock {
        private double seconds;
        void set(double s) { this.seconds = s; }
        @Override public double currentTime() { return seconds; }
    }

    private Controller start(SrangerTestAdapter.Sensor sensor,
                             SrangerTestAdapter.Actuator actuator,
                             Time time) {
        final HarnessClock clock = new HarnessClock();
        clock.set(time.seconds());
        final com.sranger.sensor.Sensor sutSensor = new com.sranger.sensor.Sensor();
        sutSensor.updateDistance(sensor.distance());
        final com.sranger.actuator.Actuator sutActuator = new com.sranger.actuator.Actuator();
        // A2: forward every Move, preserving duplicates/zeros/order.
        sutActuator.setObserver(new com.sranger.actuator.Actuator.MoveObserver() {
            @Override public void onMove(double lv, double av) { actuator.move(lv, av); }
        });
        // A8: receiver wired BEFORE construction so the startup Move is observed.
        final SRangerController sut = new SRangerController(sutSensor, sutActuator, clock);

        return new Controller() {
            private void sync() {
                clock.set(time.seconds());
                sutSensor.updateDistance(sensor.distance());
            }
            @Override public Mode mode() {
                com.sranger.controller.Mode m = sut.currentMode();
                if (m == com.sranger.controller.Mode.MOVING) return Mode.MOVING;
                if (m == com.sranger.controller.Mode.TURNING) return Mode.TURNING;
                return Mode.FINAL;
            }
            @Override public void obstacle() { sync(); sut.step(new ObstacleEvent()); }
            @Override public void tick()     { sync(); sut.step(new TickEvent()); }
            @Override public void endTask()  { sync(); sut.step(new EndTaskEvent()); }
            // A6: settle at Time.seconds() WITHOUT delivering an input event; a null
            // event traverses only guard-only branches (SUT's own autonomous logic).
            @Override public void runUntilIdle() { sync(); sut.step(null); }
        };
    }

    @Override
    public Controller startDefault(SrangerTestAdapter.Sensor s,
                                   SrangerTestAdapter.Actuator a, Time t) {
        SRangerConstants.harnessReset();                    // A8: SUT's own defaults
        return start(s, a, t);
    }

    @Override
    public Controller startConfigured(Config c, SrangerTestAdapter.Sensor s,
                                      SrangerTestAdapter.Actuator a, Time t) {
        SRangerConstants.harnessConfigure(c.moveVel(), c.turnVel(),
                c.obstacleThreshold(), c.turnDuration());
        return start(s, a, t);
    }
}
