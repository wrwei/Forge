# Static analysis (SpotBugs 4.8.6) — FAILED

## Summary
SpotBugs 4.8.6 (default ruleset, -effort:default -low): 9 instance(s) total, 3 above the reference noise floor (13 instances at this threshold).

## Run history
- New this run: 3
- Recurring from previous run: 0
- Resolved since previous run: 0

## Issues
### Issue 1: MS_PKGPROTECT — MS_PKGPROTECT in com.sranger.controller.SRangerConstants

**Raw**
```
com.sranger.controller.SRangerConstants.MOVE_VEL should be package protected
```

**Java trace**
  - Java: `SRangerConstants.java`:24
  - Requirement(s): SR-DM2, SR-FR1, SR-FR2

**Fix directive**
SpotBugs flags this construct above the recorded reference noise floor. Rework the flagged code so the detector no longer fires; do not suppress with annotations.

### Issue 2: MS_PKGPROTECT — MS_PKGPROTECT in com.sranger.controller.SRangerConstants

**Raw**
```
com.sranger.controller.SRangerConstants.OBSTACLE_THRESHOLD should be package protected
```

**Java trace**
  - Java: `SRangerConstants.java`:32
  - Requirement(s): SR-DM2, SR-FR1, SR-FR2

**Fix directive**
SpotBugs flags this construct above the recorded reference noise floor. Rework the flagged code so the detector no longer fires; do not suppress with annotations.

### Issue 3: MS_PKGPROTECT — MS_PKGPROTECT in com.sranger.controller.SRangerConstants

**Raw**
```
com.sranger.controller.SRangerConstants.TURN_DURATION should be package protected
```

**Java trace**
  - Java: `SRangerConstants.java`:36
  - Requirement(s): SR-DM2, SR-FR1, SR-FR2

**Fix directive**
SpotBugs flags this construct above the recorded reference noise floor. Rework the flagged code so the detector no longer fires; do not suppress with annotations.

## Files to review
- SRangerConstants.java (requirements: SR-DM2, SR-FR1, SR-FR2)

## Next step
Read each issue above, follow the fix directive, edit the linked Java file, and re-run static analysis.
