package com.sranger.actuator;

import com.sranger.annotation.RoboChartType;
import com.sranger.event.MoveEvent;

/**
 * Receives Move commands from the controller and records the latest
 * issued linear / angular velocity for inspection.
 */
public class Actuator {

    @RoboChartType("real")
    private double lastLinearVelocity;

    @RoboChartType("real")
    private double lastAngularVelocity;

    /** HARNESS INSTRUMENTATION (T-arm adapter): forwards every receive() to an
     *  observer so tests can see each Move (duplicates and order preserved).
     *  Storage behaviour unchanged. */
    public interface MoveObserver { void onMove(double lv, double av); }
    private MoveObserver observer;
    public void setObserver(MoveObserver o) { this.observer = o; }

    /**
     * Stores the linear and angular velocity carried by the given Move
     * command as the latest issued command.
     */
    public void receive(MoveEvent move) {
        this.lastLinearVelocity = move.linearVelocity();
        this.lastAngularVelocity = move.angularVelocity();
        if (observer != null) observer.onMove(move.linearVelocity(), move.angularVelocity());
    }

    /** Returns the last commanded linear velocity, in m/s. */
    @RoboChartType("real")
    public double lastLinearVelocity() {
        return this.lastLinearVelocity;
    }

    /** Returns the last commanded angular velocity, in rad/s. */
    @RoboChartType("real")
    public double lastAngularVelocity() {
        return this.lastAngularVelocity;
    }
}
