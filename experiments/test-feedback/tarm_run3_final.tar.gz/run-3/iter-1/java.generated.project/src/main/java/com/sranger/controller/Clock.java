package com.sranger.controller;

import com.sranger.annotation.RoboChartType;

/**
 * Source of the current time, in seconds, used to time the Turning to
 * Moving autonomous transition.
 */
public interface Clock {

    @RoboChartType("real")
    double currentTime();
}
