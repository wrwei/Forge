package com.sranger.controller;

import com.sranger.annotation.RoboChartType;

/**
 * Fixed configuration constants for the SRanger controller.
 */
public final class SRangerConstants {
    /** HARNESS INSTRUMENTATION (T-arm adapter): fields de-finalised so the test
     *  adapter can supply configuration per Config record (A4/A8). Defaults below
     *  are the SUT's own and are restored before every startDefault(). */
    public static void harnessReset() {
        MOVE_VEL = 1.0; TURN_VEL = 2.0; OBSTACLE_THRESHOLD = 0.5; TURN_DURATION = 2.0;
    }
    public static void harnessConfigure(double mv, double tv, double th, double td) {
        MOVE_VEL = mv; TURN_VEL = tv; OBSTACLE_THRESHOLD = th; TURN_DURATION = td;
    }

    private SRangerConstants() {
    }

    /** Linear velocity command when Moving, in m/s. */
    @RoboChartType("real")
    public static double MOVE_VEL = 1.0;

    /** Angular velocity command when Turning, in rad/s. */
    @RoboChartType("real")
    public static double TURN_VEL = 2.0;

    /** IR-distance threshold for the obstacle-detection condition, in metres. */
    @RoboChartType("real")
    public static double OBSTACLE_THRESHOLD = 0.5;

    /** How long the controller remains in Turning before returning to Moving, in seconds. */
    @RoboChartType("real")
    public static double TURN_DURATION = 2.0;
}
