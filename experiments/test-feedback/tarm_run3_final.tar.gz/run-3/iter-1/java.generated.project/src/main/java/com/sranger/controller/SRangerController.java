package com.sranger.controller;

import com.sranger.actuator.Actuator;
import com.sranger.annotation.RoboChartType;
import com.sranger.event.EndTaskEvent;
import com.sranger.event.InputEvent;
import com.sranger.event.MoveEvent;
import com.sranger.event.ObstacleEvent;
import com.sranger.event.TickEvent;
import com.sranger.sensor.Sensor;

/**
 * Reactive SRanger controller: drives forward, turns in place on obstacle
 * detection, and halts on operator shutdown.
 */
public final class SRangerController {

    private final Sensor sensor;
    private final Actuator actuator;
    private final Clock cycleClock;

    private Mode currentMode = Mode.MOVING;

    @RoboChartType("real")
    private double clockResetTime;

    public SRangerController(Sensor sensor, Actuator actuator, Clock cycleClock) {
        this.sensor = sensor;
        this.actuator = actuator;
        this.cycleClock = cycleClock;
        this.actuator.receive(new MoveEvent(SRangerConstants.MOVE_VEL, 0.0));
    }

    /**
     * Handles the given input event (or an autonomous timing check) and
     * advances the controller's mode, issuing Move commands as needed.
     */
    public void step(InputEvent event) {
        boolean obstacleDetected = this.sensor.distance() <= SRangerConstants.OBSTACLE_THRESHOLD;
        boolean turnDurationElapsed = (this.cycleClock.currentTime() - this.clockResetTime) >= SRangerConstants.TURN_DURATION;

        if (this.currentMode == Mode.MOVING) {
            if (event instanceof EndTaskEvent) {
                this.currentMode = Mode.FINAL;
                this.actuator.receive(new MoveEvent(0.0, 0.0));
            } else if (event instanceof ObstacleEvent && obstacleDetected) {
                this.clockResetTime = this.cycleClock.currentTime();
                this.currentMode = Mode.TURNING;
                this.actuator.receive(new MoveEvent(0.0, SRangerConstants.TURN_VEL));
            } else if (event instanceof TickEvent) {
                this.currentMode = Mode.MOVING;
            }
        } else if (this.currentMode == Mode.TURNING) {
            if (event instanceof EndTaskEvent) {
                this.currentMode = Mode.FINAL;
                this.actuator.receive(new MoveEvent(0.0, 0.0));
            } else if (turnDurationElapsed) {
                this.currentMode = Mode.MOVING;
                this.actuator.receive(new MoveEvent(SRangerConstants.MOVE_VEL, 0.0));
            } else if (event instanceof TickEvent) {
                this.currentMode = Mode.TURNING;
            }
        } else if (this.currentMode == Mode.FINAL) {
            this.currentMode = Mode.FINAL;
        }
    }

    /** Returns the controller's current mode. */
    public Mode currentMode() {
        return this.currentMode;
    }

    /** Returns the time (seconds) at which Turning was most recently entered. */
    @RoboChartType("real")
    public double clockResetTime() {
        return this.clockResetTime;
    }
}
