package com.sranger.controller;

import com.sranger.annotation.RoboChartType;

/**
 * Wall-clock based implementation of {@link Clock}.
 */
public final class SystemClock implements Clock {

    @Override
    @RoboChartType("real")
    public double currentTime() {
        return System.nanoTime() / 1_000_000_000.0;
    }
}
