package com.sranger.demo;

import com.sranger.actuator.Actuator;
import com.sranger.controller.SRangerController;
import com.sranger.controller.SystemClock;
import com.sranger.event.EndTaskEvent;
import com.sranger.event.ObstacleEvent;
import com.sranger.event.TickEvent;
import com.sranger.sensor.Sensor;

/**
 * Demonstration entry point that runs the SRanger controller through a
 * short scripted scenario.
 */
public final class SRangerDemo {

    private SRangerDemo() {
    }

    public static void main(String[] args) {
        var sensor = new Sensor();
        var actuator = new Actuator();
        var controller = new SRangerController(sensor, actuator, new SystemClock());

        System.out.println("Initial mode: " + controller.currentMode());

        controller.step(new TickEvent());
        System.out.println("After tick: " + controller.currentMode());

        sensor.updateDistance(0.3);
        controller.step(new ObstacleEvent());
        System.out.println("After obstacle: " + controller.currentMode());

        controller.step(new EndTaskEvent());
        System.out.println("After endTask: " + controller.currentMode());
    }
}
