package com.sranger.event;

/**
 * Signal emitted by the operator-level shutdown channel to terminate the
 * controller into the Final mode.
 */
public record EndTaskEvent() implements InputEvent {
}
