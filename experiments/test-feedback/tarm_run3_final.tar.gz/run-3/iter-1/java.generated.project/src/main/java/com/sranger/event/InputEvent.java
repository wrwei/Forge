package com.sranger.event;

/**
 * The sealed set of input events the SRanger controller reacts to.
 */
public sealed interface InputEvent permits ObstacleEvent, TickEvent, EndTaskEvent {
}
