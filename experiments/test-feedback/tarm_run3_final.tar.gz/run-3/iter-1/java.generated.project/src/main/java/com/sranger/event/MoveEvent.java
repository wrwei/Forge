package com.sranger.event;

import com.sranger.annotation.RoboChartType;

/**
 * Combined linear / angular velocity command issued to the differential
 * drive layer. Covers forward motion, in-place turning, and stopping.
 */
public record MoveEvent(
        @RoboChartType("real") double linearVelocity,
        @RoboChartType("real") double angularVelocity) implements OutputEvent {
}
