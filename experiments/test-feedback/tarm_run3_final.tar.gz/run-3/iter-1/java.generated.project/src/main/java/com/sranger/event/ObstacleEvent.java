package com.sranger.event;

/**
 * Signal emitted by the IR sensor framework when the distance reading
 * crosses below the obstacle-detection threshold.
 */
public record ObstacleEvent() implements InputEvent {
}
