package com.sranger.event;

/**
 * The sealed set of output events the SRanger controller emits to the
 * differential-drive layer.
 */
public sealed interface OutputEvent permits MoveEvent {
}
