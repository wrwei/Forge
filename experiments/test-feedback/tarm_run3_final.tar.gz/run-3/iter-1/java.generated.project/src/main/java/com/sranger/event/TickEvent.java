package com.sranger.event;

/**
 * Signal delivered each control cycle by the system framework.
 */
public record TickEvent() implements InputEvent {
}
