package com.sranger.actuator;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.sranger.event.MoveEvent;
import org.junit.jupiter.api.Test;

class ActuatorTest {

    @Test
    void receiveStoresLastCommand() {
        var actuator = new Actuator();
        actuator.receive(new MoveEvent(1.0, 0.0));
        assertEquals(1.0, actuator.lastLinearVelocity());
        assertEquals(0.0, actuator.lastAngularVelocity());
        actuator.receive(new MoveEvent(0.0, 2.0));
        assertEquals(0.0, actuator.lastLinearVelocity());
        assertEquals(2.0, actuator.lastAngularVelocity());
    }
}
