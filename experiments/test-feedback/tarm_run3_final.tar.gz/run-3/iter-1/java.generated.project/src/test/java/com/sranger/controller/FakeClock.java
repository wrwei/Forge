package com.sranger.controller;

final class FakeClock implements Clock {

    private double time;

    void set(double time) {
        this.time = time;
    }

    @Override
    public double currentTime() {
        return this.time;
    }
}
