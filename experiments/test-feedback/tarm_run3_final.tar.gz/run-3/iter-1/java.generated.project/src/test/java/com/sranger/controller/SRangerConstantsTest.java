package com.sranger.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class SRangerConstantsTest {

    @Test
    void defaultValuesMatchSpecification() {
        assertEquals(1.0, SRangerConstants.MOVE_VEL);
        assertEquals(2.0, SRangerConstants.TURN_VEL);
        assertEquals(0.5, SRangerConstants.OBSTACLE_THRESHOLD);
        assertEquals(2.0, SRangerConstants.TURN_DURATION);
    }
}
