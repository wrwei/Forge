package com.sranger.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.sranger.actuator.Actuator;
import com.sranger.event.EndTaskEvent;
import com.sranger.event.ObstacleEvent;
import com.sranger.event.TickEvent;
import com.sranger.sensor.Sensor;
import org.junit.jupiter.api.Test;

class SRangerControllerTest {

    @Test
    void startsInMovingModeAndIssuesForwardCommand() {
        var sensor = new Sensor();
        var actuator = new Actuator();
        var clock = new FakeClock();
        var controller = new SRangerController(sensor, actuator, clock);

        assertEquals(Mode.MOVING, controller.currentMode());
        assertEquals(SRangerConstants.MOVE_VEL, actuator.lastLinearVelocity());
        assertEquals(0.0, actuator.lastAngularVelocity());
    }

    @Test
    void movingToTurningOnObstacle() {
        var sensor = new Sensor();
        var actuator = new Actuator();
        var clock = new FakeClock();
        var controller = new SRangerController(sensor, actuator, clock);

        sensor.updateDistance(0.2);
        clock.set(10.0);
        controller.step(new ObstacleEvent());

        assertEquals(Mode.TURNING, controller.currentMode());
        assertEquals(0.0, actuator.lastLinearVelocity());
        assertEquals(SRangerConstants.TURN_VEL, actuator.lastAngularVelocity());
        assertEquals(10.0, controller.clockResetTime());
    }

    @Test
    void turningToMovingAfterDuration() {
        var sensor = new Sensor();
        var actuator = new Actuator();
        var clock = new FakeClock();
        var controller = new SRangerController(sensor, actuator, clock);

        sensor.updateDistance(0.2);
        clock.set(10.0);
        controller.step(new ObstacleEvent());

        clock.set(12.0);
        controller.step(new TickEvent());

        assertEquals(Mode.MOVING, controller.currentMode());
        assertEquals(SRangerConstants.MOVE_VEL, actuator.lastLinearVelocity());
        assertEquals(0.0, actuator.lastAngularVelocity());
    }

    @Test
    void endTaskFromMovingGoesToFinal() {
        var sensor = new Sensor();
        var actuator = new Actuator();
        var clock = new FakeClock();
        var controller = new SRangerController(sensor, actuator, clock);

        controller.step(new EndTaskEvent());

        assertEquals(Mode.FINAL, controller.currentMode());
        assertEquals(0.0, actuator.lastLinearVelocity());
        assertEquals(0.0, actuator.lastAngularVelocity());
    }

    @Test
    void endTaskFromTurningGoesToFinal() {
        var sensor = new Sensor();
        var actuator = new Actuator();
        var clock = new FakeClock();
        var controller = new SRangerController(sensor, actuator, clock);

        sensor.updateDistance(0.2);
        controller.step(new ObstacleEvent());
        controller.step(new EndTaskEvent());

        assertEquals(Mode.FINAL, controller.currentMode());
        assertEquals(0.0, actuator.lastLinearVelocity());
        assertEquals(0.0, actuator.lastAngularVelocity());
    }

    @Test
    void tickInMovingWithNoObstacleStaysMoving() {
        var sensor = new Sensor();
        var actuator = new Actuator();
        var clock = new FakeClock();
        var controller = new SRangerController(sensor, actuator, clock);

        controller.step(new TickEvent());

        assertEquals(Mode.MOVING, controller.currentMode());
    }

    @Test
    void tickInTurningBeforeDurationStaysTurning() {
        var sensor = new Sensor();
        var actuator = new Actuator();
        var clock = new FakeClock();
        var controller = new SRangerController(sensor, actuator, clock);

        sensor.updateDistance(0.2);
        clock.set(10.0);
        controller.step(new ObstacleEvent());

        clock.set(10.5);
        controller.step(new TickEvent());

        assertEquals(Mode.TURNING, controller.currentMode());
    }
}
