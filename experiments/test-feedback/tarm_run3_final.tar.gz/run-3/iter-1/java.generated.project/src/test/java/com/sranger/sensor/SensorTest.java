package com.sranger.sensor;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class SensorTest {

    @Test
    void defaultDistanceIsLarge() {
        var sensor = new Sensor();
        assertTrue(sensor.distance() > 100.0);
    }

    @Test
    void updateDistanceStoresNonNegativeReading() {
        var sensor = new Sensor();
        sensor.updateDistance(0.3);
        assertEquals(0.3, sensor.distance());
    }

    @Test
    void updateDistanceIgnoresNegativeReading() {
        var sensor = new Sensor();
        sensor.updateDistance(0.3);
        sensor.updateDistance(-1.0);
        assertEquals(0.3, sensor.distance());
    }
}
