# Static analysis (SpotBugs 4.8.6) — PASSED

## Summary
SpotBugs 4.8.6 (default ruleset, -effort:default -low): 1 instance(s) total, 0 above the reference noise floor (13 instances at this threshold).

## Run history
- New this run: 0
- Recurring from previous run: 0
- Resolved since previous run: 1

**Resolved issue titles**
- MS_PKGPROTECT in com.sranger.controller.SRangerConstants

## Issues
None.

## Files to review
(none identified)

## Next step
Static analysis clean at the recorded threshold.
